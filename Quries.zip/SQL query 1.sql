-- Order-status target structure
SELECT
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE,
    ORDINAL_POSITION
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME IN ('DimOrderStatus', 'DimPaymentType')
ORDER BY TABLE_NAME, ORDINAL_POSITION;

-- Payment source structure
SELECT
    COLUMN_NAME,
    DATA_TYPE,
    ORDINAL_POSITION
FROM [LH_Olist_Medallion].INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'silver'
  AND TABLE_NAME = 'payments'
ORDER BY ORDINAL_POSITION;


SELECT
    COLUMN_NAME,
    DATA_TYPE,
    ORDINAL_POSITION
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME = 'DimGeography'
ORDER BY ORDINAL_POSITION;


SELECT
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    ORDINAL_POSITION
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME = 'FactPayments'
ORDER BY ORDINAL_POSITION;




SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME IN (
      'DimDate',
      'DimCustomer',
      'DimProduct',
      'DimSeller',
      'DimGeography',
      'DimOrderStatus',
      'DimPaymentType',
      'FactOrders',
      'FactSales',
      'FactPayments',
      'FactReviews'
  )
ORDER BY
    TABLE_NAME,
    ORDINAL_POSITION;




---------------------------------------------------------------
-- Check 5: Dimension surrogate keys must be unique
---------------------------------------------------------------
IF EXISTS (
    SELECT CustomerKey
    FROM gold.DimCustomer
    GROUP BY CustomerKey
    HAVING CustomerKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51023, 'VALIDATION FAILED: Invalid CustomerKey values in DimCustomer.', 1;

IF EXISTS (
    SELECT ProductKey
    FROM gold.DimProduct
    GROUP BY ProductKey
    HAVING ProductKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51024, 'VALIDATION FAILED: Invalid ProductKey values in DimProduct.', 1;

IF EXISTS (
    SELECT SellerKey
    FROM gold.DimSeller
    GROUP BY SellerKey
    HAVING SellerKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51025, 'VALIDATION FAILED: Invalid SellerKey values in DimSeller.', 1;

IF EXISTS (
    SELECT GeographyKey
    FROM gold.DimGeography
    GROUP BY GeographyKey
    HAVING GeographyKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51026, 'VALIDATION FAILED: Invalid GeographyKey values in DimGeography.', 1;

IF EXISTS (
    SELECT OrderStatusKey
    FROM gold.DimOrderStatus
    GROUP BY OrderStatusKey
    HAVING OrderStatusKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51027, 'VALIDATION FAILED: Invalid OrderStatusKey values in DimOrderStatus.', 1;

IF EXISTS (
    SELECT PaymentTypeKey
    FROM gold.DimPaymentType
    GROUP BY PaymentTypeKey
    HAVING PaymentTypeKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51028, 'VALIDATION FAILED: Invalid PaymentTypeKey values in DimPaymentType.', 1;

IF EXISTS (
    SELECT DateKey
    FROM gold.DimDate
    GROUP BY DateKey
    HAVING DateKey IS NULL OR COUNT_BIG(*) > 1
)
    THROW 51029, 'VALIDATION FAILED: Invalid DateKey values in DimDate.', 1;


---------------------------------------------------------------
-- Check 6: Foreign keys must reference existing dimensions
---------------------------------------------------------------

-- FactOrders
IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimCustomer d
        ON f.CustomerKey = d.CustomerKey
    WHERE d.CustomerKey IS NULL
)
    THROW 51030, 'VALIDATION FAILED: Invalid CustomerKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimGeography d
        ON f.CustomerGeographyKey = d.GeographyKey
    WHERE d.GeographyKey IS NULL
)
    THROW 51031, 'VALIDATION FAILED: Invalid GeographyKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimOrderStatus d
        ON f.OrderStatusKey = d.OrderStatusKey
    WHERE d.OrderStatusKey IS NULL
)
    THROW 51032, 'VALIDATION FAILED: Invalid OrderStatusKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimDate d
        ON f.PurchaseDateKey = d.DateKey
    WHERE d.DateKey IS NULL
)
    THROW 51033, 'VALIDATION FAILED: Invalid PurchaseDateKey in FactOrders.', 1;

-- FactSales
IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimProduct d
        ON f.ProductKey = d.ProductKey
    WHERE d.ProductKey IS NULL
)
    THROW 51034, 'VALIDATION FAILED: Invalid ProductKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimSeller d
        ON f.SellerKey = d.SellerKey
    WHERE d.SellerKey IS NULL
)
    THROW 51035, 'VALIDATION FAILED: Invalid SellerKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimCustomer d
        ON f.CustomerKey = d.CustomerKey
    WHERE d.CustomerKey IS NULL
)
    THROW 51036, 'VALIDATION FAILED: Invalid CustomerKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimGeography d
        ON f.CustomerGeographyKey = d.GeographyKey
    WHERE d.GeographyKey IS NULL
)
    THROW 51037, 'VALIDATION FAILED: Invalid GeographyKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimOrderStatus d
        ON f.OrderStatusKey = d.OrderStatusKey
    WHERE d.OrderStatusKey IS NULL
)
    THROW 51038, 'VALIDATION FAILED: Invalid OrderStatusKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimDate d
        ON f.PurchaseDateKey = d.DateKey
    WHERE d.DateKey IS NULL
)
    THROW 51039, 'VALIDATION FAILED: Invalid PurchaseDateKey in FactSales.', 1;

-- FactPayments
IF EXISTS (
    SELECT 1
    FROM gold.FactPayments f
    LEFT JOIN gold.DimPaymentType d
        ON f.PaymentTypeKey = d.PaymentTypeKey
    WHERE d.PaymentTypeKey IS NULL
)
    THROW 51040, 'VALIDATION FAILED: Invalid PaymentTypeKey in FactPayments.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactPayments f
    LEFT JOIN gold.DimCustomer d
        ON f.CustomerKey = d.CustomerKey
    WHERE d.CustomerKey IS NULL
)
    THROW 51041, 'VALIDATION FAILED: Invalid CustomerKey in FactPayments.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactPayments f
    LEFT JOIN gold.DimGeography d
        ON f.CustomerGeographyKey = d.GeographyKey
    WHERE d.GeographyKey IS NULL
)
    THROW 51042, 'VALIDATION FAILED: Invalid GeographyKey in FactPayments.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactPayments f
    LEFT JOIN gold.DimOrderStatus d
        ON f.OrderStatusKey = d.OrderStatusKey
    WHERE d.OrderStatusKey IS NULL
)
    THROW 51043, 'VALIDATION FAILED: Invalid OrderStatusKey in FactPayments.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactPayments f
    LEFT JOIN gold.DimDate d
        ON f.PurchaseDateKey = d.DateKey
    WHERE d.DateKey IS NULL
)
    THROW 51044, 'VALIDATION FAILED: Invalid PurchaseDateKey in FactPayments.', 1;

-- FactReviews
IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimCustomer d
        ON f.CustomerKey = d.CustomerKey
    WHERE d.CustomerKey IS NULL
)
    THROW 51045, 'VALIDATION FAILED: Invalid CustomerKey in FactReviews.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimGeography d
        ON f.CustomerGeographyKey = d.GeographyKey
    WHERE d.GeographyKey IS NULL
)
    THROW 51046, 'VALIDATION FAILED: Invalid GeographyKey in FactReviews.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimOrderStatus d
        ON f.OrderStatusKey = d.OrderStatusKey
    WHERE d.OrderStatusKey IS NULL
)
    THROW 51047, 'VALIDATION FAILED: Invalid OrderStatusKey in FactReviews.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimDate d
        ON f.ReviewCreationDateKey = d.DateKey
    WHERE d.DateKey IS NULL
)
    THROW 51048, 'VALIDATION FAILED: Invalid ReviewCreationDateKey in FactReviews.', 1;

-- Validate optional date keys only when they are populated.
-- NULL is permitted for dates that are not yet available.
IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimDate d
        ON f.ApprovalDateKey = d.DateKey
    WHERE f.ApprovalDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51049, 'VALIDATION FAILED: Invalid ApprovalDateKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimDate d
        ON f.CarrierDateKey = d.DateKey
    WHERE f.CarrierDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51050, 'VALIDATION FAILED: Invalid CarrierDateKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimDate d
        ON f.DeliveredDateKey = d.DateKey
    WHERE f.DeliveredDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51051, 'VALIDATION FAILED: Invalid DeliveredDateKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactOrders f
    LEFT JOIN gold.DimDate d
        ON f.EstimatedDeliveryDateKey = d.DateKey
    WHERE f.EstimatedDeliveryDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51052, 'VALIDATION FAILED: Invalid EstimatedDeliveryDateKey in FactOrders.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactSales f
    LEFT JOIN gold.DimDate d
        ON f.ShippingLimitDateKey = d.DateKey
    WHERE f.ShippingLimitDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51053, 'VALIDATION FAILED: Invalid ShippingLimitDateKey in FactSales.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimDate d
        ON f.DeliveredDateKey = d.DateKey
    WHERE f.DeliveredDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51054, 'VALIDATION FAILED: Invalid DeliveredDateKey in FactReviews.', 1;

IF EXISTS (
    SELECT 1
    FROM gold.FactReviews f
    LEFT JOIN gold.DimDate d
        ON f.ReviewAnswerDateKey = d.DateKey
    WHERE f.ReviewAnswerDateKey IS NOT NULL
      AND d.DateKey IS NULL
)
    THROW 51055, 'VALIDATION FAILED: Invalid ReviewAnswerDateKey in FactReviews.', 1;
