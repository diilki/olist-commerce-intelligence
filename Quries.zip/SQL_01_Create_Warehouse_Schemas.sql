/*==============================================================
  Project: Olist Commerce Intelligence
  Script : SQL_01_Create_Warehouse_Schemas
  Purpose: Create schemas for Gold modelling, ETL and auditing
==============================================================*/

IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'gold'
)
BEGIN
    EXEC('CREATE SCHEMA gold');
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'etl'
)
BEGIN
    EXEC('CREATE SCHEMA etl');
END;
GO

IF NOT EXISTS (
    SELECT 1
    FROM sys.schemas
    WHERE name = 'audit'
)
BEGIN
    EXEC('CREATE SCHEMA audit');
END;
GO

SELECT
    name AS schema_name
FROM sys.schemas
WHERE name IN ('gold', 'etl', 'audit')
ORDER BY name;