/*==============================================================
  Project: Olist Commerce Intelligence
  Script : SQL_02_Validate_Silver_Source
  Purpose: Confirm that the Warehouse can access every validated
           Silver Lakehouse table before Gold loading begins
==============================================================*/

SELECT 'customers' AS table_name, COUNT_BIG(*) AS row_count
FROM [LH_Olist_Medallion].[silver].[customers]

UNION ALL

SELECT 'sellers', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[sellers]

UNION ALL

SELECT 'product_category_translation', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[product_category_translation]

UNION ALL

SELECT 'products', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[products]

UNION ALL

SELECT 'orders', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[orders]

UNION ALL

SELECT 'order_items', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[order_items]

UNION ALL

SELECT 'order_payments', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[order_payments]

UNION ALL

SELECT 'order_reviews', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[order_reviews]

UNION ALL

SELECT 'geolocation', COUNT_BIG(*)
FROM [LH_Olist_Medallion].[silver].[geolocation]

ORDER BY table_name;