/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_03_Create_DimDate
  Purpose : Create and load the shared Gold calendar dimension

  Calendar range: 2016-01-01 to 2020-12-31
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create DimDate if it does not already exist
---------------------------------------------------------------

IF OBJECT_ID('gold.DimDate', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimDate
    (
        DateKey          INT          NOT NULL,
        FullDate         DATE         NULL,
        DayNumberOfWeek  SMALLINT     NULL,
        DayName          VARCHAR(10)  NULL,
        DayOfMonth       SMALLINT     NULL,
        DayOfYear        SMALLINT     NULL,
        WeekOfYear       SMALLINT     NULL,
        MonthNumber      SMALLINT     NULL,
        MonthName        VARCHAR(10)  NULL,
        MonthShortName   VARCHAR(3)   NULL,
        QuarterNumber    SMALLINT     NULL,
        QuarterName      VARCHAR(7)   NULL,
        YearNumber       SMALLINT     NULL,
        YearMonth        CHAR(7)      NULL,
        IsWeekend        BIT          NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Remove existing records
-- This allows the script to be run again safely during setup
---------------------------------------------------------------

DELETE FROM gold.DimDate;
GO

---------------------------------------------------------------
-- STEP 3: Insert the Unknown date record
-- DateKey 0 will be used when a source date is unavailable
---------------------------------------------------------------

INSERT INTO gold.DimDate
(
    DateKey,
    FullDate,
    DayNumberOfWeek,
    DayName,
    DayOfMonth,
    DayOfYear,
    WeekOfYear,
    MonthNumber,
    MonthName,
    MonthShortName,
    QuarterNumber,
    QuarterName,
    YearNumber,
    YearMonth,
    IsWeekend
)
VALUES
(
    0,
    NULL,
    NULL,
    'Unknown',
    NULL,
    NULL,
    NULL,
    NULL,
    'Unknown',
    'UNK',
    NULL,
    'Unknown',
    NULL,
    'Unknown',
    NULL
);
GO

---------------------------------------------------------------
-- STEP 4: Generate all dates from 2016 through 2020
---------------------------------------------------------------

WITH Digits AS
(
    SELECT number
    FROM
    (
        VALUES
            (0), (1), (2), (3), (4),
            (5), (6), (7), (8), (9)
    ) AS D(number)
),
Numbers AS
(
    SELECT
          Ones.number
        + Tens.number * 10
        + Hundreds.number * 100
        + Thousands.number * 1000 AS DayOffset
    FROM Digits AS Ones
    CROSS JOIN Digits AS Tens
    CROSS JOIN Digits AS Hundreds
    CROSS JOIN Digits AS Thousands
),
CalendarDates AS
(
    SELECT
        CAST
        (
            DATEADD
            (
                DAY,
                DayOffset,
                CAST('2016-01-01' AS DATE)
            )
            AS DATE
        ) AS FullDate
    FROM Numbers
    WHERE DATEADD
          (
              DAY,
              DayOffset,
              CAST('2016-01-01' AS DATE)
          ) <= CAST('2020-12-31' AS DATE)
)
INSERT INTO gold.DimDate
(
    DateKey,
    FullDate,
    DayNumberOfWeek,
    DayName,
    DayOfMonth,
    DayOfYear,
    WeekOfYear,
    MonthNumber,
    MonthName,
    MonthShortName,
    QuarterNumber,
    QuarterName,
    YearNumber,
    YearMonth,
    IsWeekend
)
SELECT
    -- Example: 2018-05-20 becomes 20180520
    CAST(CONVERT(CHAR(8), FullDate, 112) AS INT)
        AS DateKey,

    FullDate,

    CAST(DATEPART(WEEKDAY, FullDate) AS SMALLINT)
        AS DayNumberOfWeek,

    DATENAME(WEEKDAY, FullDate)
        AS DayName,

    CAST(DAY(FullDate) AS SMALLINT)
        AS DayOfMonth,

    CAST(DATEPART(DAYOFYEAR, FullDate) AS SMALLINT)
        AS DayOfYear,

    CAST(DATEPART(WEEK, FullDate) AS SMALLINT)
        AS WeekOfYear,

    CAST(MONTH(FullDate) AS SMALLINT)
        AS MonthNumber,

    DATENAME(MONTH, FullDate)
        AS MonthName,

    LEFT(DATENAME(MONTH, FullDate), 3)
        AS MonthShortName,

    CAST(DATEPART(QUARTER, FullDate) AS SMALLINT)
        AS QuarterNumber,

    CONCAT
    (
        'Q',
        DATEPART(QUARTER, FullDate)
    ) AS QuarterName,

    CAST(YEAR(FullDate) AS SMALLINT)
        AS YearNumber,

    CONCAT
    (
        YEAR(FullDate),
        '-',
        RIGHT
        (
            CONCAT('0', MONTH(FullDate)),
            2
        )
    ) AS YearMonth,

    CASE
        WHEN DATEDIFF(DAY, '19000101', FullDate) % 7 IN (5, 6)
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsWeekend

FROM CalendarDates;
GO

---------------------------------------------------------------
-- STEP 5: Quality validation
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalRows,
    COUNT_BIG(DISTINCT DateKey) AS UniqueDateKeys,
    MIN(FullDate) AS FirstCalendarDate,
    MAX(FullDate) AS LastCalendarDate
FROM gold.DimDate;
GO

---------------------------------------------------------------
-- STEP 6: Duplicate-key check
-- This result must return zero rows
---------------------------------------------------------------

SELECT
    DateKey,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimDate
GROUP BY DateKey
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- STEP 7: Preview generated records
---------------------------------------------------------------

SELECT TOP 20
    DateKey,
    FullDate,
    DayName,
    DayOfMonth,
    MonthName,
    QuarterName,
    YearNumber,
    YearMonth,
    IsWeekend
FROM gold.DimDate
ORDER BY DateKey;
GO


/*==============================================================
  DimDate quality validation
==============================================================*/

SELECT
    COUNT_BIG(*) AS total_rows,
    COUNT_BIG(DISTINCT DateKey) AS unique_date_keys,
    MIN(FullDate) AS first_calendar_date,
    MAX(FullDate) AS last_calendar_date
FROM gold.DimDate;

-- This query must return zero rows
SELECT DateKey, COUNT_BIG(*) AS duplicate_count
FROM gold.DimDate
GROUP BY DateKey
HAVING COUNT_BIG(*) > 1;

-- Preview the dimension
SELECT TOP 20 *
FROM gold.DimDate
ORDER BY DateKey;