/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_04_Create_DimCustomer
  Purpose : Create and load the Gold customer dimension

  Grain   : One row per customer_unique_id
  Method  : SCD Type 1 / latest known customer attributes
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create the dimension
-- CustomerKey is a warehouse-generated surrogate key
---------------------------------------------------------------

IF OBJECT_ID('gold.DimCustomer', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimCustomer
    (
        CustomerKey            BIGINT IDENTITY NOT NULL,
        CustomerUniqueID       VARCHAR(50)      NOT NULL,
        CustomerZipCodePrefix  INT              NULL,
        CustomerCity           VARCHAR(100)     NOT NULL,
        CustomerState          CHAR(2)          NOT NULL,
        CustomerRegion         VARCHAR(20)      NOT NULL,
        IsActive               BIT              NOT NULL,
        LoadTimestamp          DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear previous development load
-- This makes the initial-development script repeatable
---------------------------------------------------------------

DELETE FROM gold.DimCustomer;
GO

---------------------------------------------------------------
-- STEP 3: Insert the Unknown customer
-- Key 0 will be used when a customer lookup fails
---------------------------------------------------------------

SET IDENTITY_INSERT gold.DimCustomer ON;
GO

INSERT INTO gold.DimCustomer
(
    CustomerKey,
    CustomerUniqueID,
    CustomerZipCodePrefix,
    CustomerCity,
    CustomerState,
    CustomerRegion,
    IsActive,
    LoadTimestamp
)
VALUES
(
    0,
    'UNKNOWN',
    NULL,
    'Unknown',
    'UN',
    'Unknown',
    CAST(1 AS BIT),
    SYSUTCDATETIME()
);
GO

SET IDENTITY_INSERT gold.DimCustomer OFF;
GO

---------------------------------------------------------------
-- STEP 4: Rank customer records
--
-- Some real customers have placed multiple orders and therefore
-- have multiple customer_id values.
--
-- We keep the location from their most recent order.
---------------------------------------------------------------

WITH RankedCustomers AS
(
    SELECT
        c.customer_unique_id,
        c.customer_zip_code_prefix,
        c.customer_city,
        c.customer_state,
        o.order_purchase_timestamp,

        ROW_NUMBER() OVER
        (
            PARTITION BY c.customer_unique_id
            ORDER BY
                o.order_purchase_timestamp DESC,
                c.customer_id DESC
        ) AS CustomerRowNumber

    FROM [LH_Olist_Medallion].[silver].[customers] AS c

    LEFT JOIN [LH_Olist_Medallion].[silver].[orders] AS o
        ON c.customer_id = o.customer_id

    WHERE c.customer_unique_id IS NOT NULL
      AND TRIM(c.customer_unique_id) <> ''
)

---------------------------------------------------------------
-- STEP 5: Load one row for each real customer
---------------------------------------------------------------

INSERT INTO gold.DimCustomer
(
    CustomerUniqueID,
    CustomerZipCodePrefix,
    CustomerCity,
    CustomerState,
    CustomerRegion,
    IsActive,
    LoadTimestamp
)
SELECT
    TRIM(customer_unique_id) AS CustomerUniqueID,

    customer_zip_code_prefix AS CustomerZipCodePrefix,

    COALESCE
    (
        NULLIF(TRIM(customer_city), ''),
        'Unknown'
    ) AS CustomerCity,

    COALESCE
    (
        NULLIF(UPPER(TRIM(customer_state)), ''),
        'UN'
    ) AS CustomerState,

    CASE

        -- North
        WHEN UPPER(TRIM(customer_state))
             IN ('AC', 'AP', 'AM', 'PA', 'RO', 'RR', 'TO')
            THEN 'North'

        -- Northeast
        WHEN UPPER(TRIM(customer_state))
             IN ('AL', 'BA', 'CE', 'MA', 'PB',
                 'PE', 'PI', 'RN', 'SE')
            THEN 'Northeast'

        -- Central-West
        WHEN UPPER(TRIM(customer_state))
             IN ('DF', 'GO', 'MT', 'MS')
            THEN 'Central-West'

        -- Southeast
        WHEN UPPER(TRIM(customer_state))
             IN ('ES', 'MG', 'RJ', 'SP')
            THEN 'Southeast'

        -- South
        WHEN UPPER(TRIM(customer_state))
             IN ('PR', 'RS', 'SC')
            THEN 'South'

        ELSE 'Unknown'

    END AS CustomerRegion,

    CAST(1 AS BIT) AS IsActive,
    SYSUTCDATETIME() AS LoadTimestamp

FROM RankedCustomers
WHERE CustomerRowNumber = 1;
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Compare total rows with unique business keys
-- These two values must be equal
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalDimensionRows,
    COUNT_BIG(DISTINCT CustomerUniqueID) AS UniqueCustomerIDs
FROM gold.DimCustomer;
GO

---------------------------------------------------------------
-- CHECK 2: Compare Silver and Gold customer counts
--
-- Gold count excludes the special Unknown row.
-- Both counts must be equal.
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(DISTINCT customer_unique_id)
        FROM [LH_Olist_Medallion].[silver].[customers]
        WHERE customer_unique_id IS NOT NULL
          AND TRIM(customer_unique_id) <> ''
    ) AS SilverUniqueCustomers,

    (
        SELECT COUNT_BIG(*)
        FROM gold.DimCustomer
        WHERE CustomerKey <> 0
    ) AS GoldKnownCustomers;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate business keys
-- This query must return zero rows
---------------------------------------------------------------

SELECT
    CustomerUniqueID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimCustomer
GROUP BY CustomerUniqueID
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Missing business keys
-- This value must be zero
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS MissingCustomerIDCount
FROM gold.DimCustomer
WHERE CustomerUniqueID IS NULL
   OR TRIM(CustomerUniqueID) = '';
GO

---------------------------------------------------------------
-- CHECK 5: Customer distribution by Brazilian region
---------------------------------------------------------------

SELECT
    CustomerRegion,
    COUNT_BIG(*) AS CustomerCount
FROM gold.DimCustomer
GROUP BY CustomerRegion
ORDER BY CustomerCount DESC;
GO

---------------------------------------------------------------
-- CHECK 6: Preview records
---------------------------------------------------------------

SELECT TOP 20
    CustomerKey,
    CustomerUniqueID,
    CustomerZipCodePrefix,
    CustomerCity,
    CustomerState,
    CustomerRegion,
    IsActive,
    LoadTimestamp
FROM gold.DimCustomer
ORDER BY CustomerKey;
GO