/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_05_Create_DimProduct
  Purpose : Create and load the Gold product dimension

  Grain   : One row per product_id
  Method  : SCD Type 1 / current product attributes
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create the product dimension
---------------------------------------------------------------

IF OBJECT_ID('gold.DimProduct', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimProduct
    (
        ProductKey                 BIGINT IDENTITY NOT NULL,
        ProductID                  VARCHAR(50)      NOT NULL,
        CategoryNamePortuguese     VARCHAR(100)     NOT NULL,
        CategoryNameEnglish        VARCHAR(100)     NOT NULL,
        CategoryTranslationStatus  VARCHAR(30)      NOT NULL,
        ProductNameLength          INT              NULL,
        ProductDescriptionLength   INT              NULL,
        ProductPhotosQuantity      INT              NULL,
        ProductWeightG             INT              NULL,
        ProductLengthCM            INT              NULL,
        ProductHeightCM            INT              NULL,
        ProductWidthCM             INT              NULL,
        ProductVolumeCM3           DECIMAL(18,2)    NULL,
        WeightCategory             VARCHAR(20)      NOT NULL,
        SizeCategory               VARCHAR(20)      NOT NULL,
        IsActive                   BIT              NOT NULL,
        LoadTimestamp              DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the development load
---------------------------------------------------------------

DELETE FROM gold.DimProduct;
GO

---------------------------------------------------------------
-- STEP 3: Insert the Unknown product
---------------------------------------------------------------

SET IDENTITY_INSERT gold.DimProduct ON;
GO

INSERT INTO gold.DimProduct
(
    ProductKey,
    ProductID,
    CategoryNamePortuguese,
    CategoryNameEnglish,
    CategoryTranslationStatus,
    ProductNameLength,
    ProductDescriptionLength,
    ProductPhotosQuantity,
    ProductWeightG,
    ProductLengthCM,
    ProductHeightCM,
    ProductWidthCM,
    ProductVolumeCM3,
    WeightCategory,
    SizeCategory,
    IsActive,
    LoadTimestamp
)
VALUES
(
    0,
    'UNKNOWN',
    'Unknown',
    'Unknown',
    'Unknown',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'Unknown',
    'Unknown',
    CAST(1 AS BIT),
    SYSUTCDATETIME()
);
GO

SET IDENTITY_INSERT gold.DimProduct OFF;
GO

---------------------------------------------------------------
-- STEP 4: Load known products from Silver
---------------------------------------------------------------

INSERT INTO gold.DimProduct
(
    ProductID,
    CategoryNamePortuguese,
    CategoryNameEnglish,
    CategoryTranslationStatus,
    ProductNameLength,
    ProductDescriptionLength,
    ProductPhotosQuantity,
    ProductWeightG,
    ProductLengthCM,
    ProductHeightCM,
    ProductWidthCM,
    ProductVolumeCM3,
    WeightCategory,
    SizeCategory,
    IsActive,
    LoadTimestamp
)
SELECT
    TRIM(product_id) AS ProductID,

    COALESCE
    (
        NULLIF(TRIM(product_category_name), ''),
        'Unknown'
    ) AS CategoryNamePortuguese,

    COALESCE
    (
        NULLIF(TRIM(product_category_name_english), ''),
        'Unknown'
    ) AS CategoryNameEnglish,

    COALESCE
    (
        NULLIF(TRIM(category_translation_status), ''),
        'Unknown'
    ) AS CategoryTranslationStatus,

    product_name_length,
    product_description_length,
    product_photos_qty,
    product_weight_g,
    product_length_cm,
    product_height_cm,
    product_width_cm,

    -----------------------------------------------------------
    -- Volume = length × height × width
    -----------------------------------------------------------

    CASE
        WHEN product_length_cm IS NULL
          OR product_height_cm IS NULL
          OR product_width_cm IS NULL
            THEN NULL

        ELSE
            CAST(product_length_cm AS DECIMAL(18,2))
            * CAST(product_height_cm AS DECIMAL(18,2))
            * CAST(product_width_cm AS DECIMAL(18,2))
    END AS ProductVolumeCM3,

    -----------------------------------------------------------
    -- Weight segmentation
    -----------------------------------------------------------

    CASE
        WHEN product_weight_g IS NULL
            THEN 'Unknown'

        WHEN product_weight_g < 1000
            THEN 'Light'

        WHEN product_weight_g < 5000
            THEN 'Medium'

        ELSE 'Heavy'
    END AS WeightCategory,

    -----------------------------------------------------------
    -- Physical-size segmentation based on cubic centimetres
    -----------------------------------------------------------

    CASE
        WHEN product_length_cm IS NULL
          OR product_height_cm IS NULL
          OR product_width_cm IS NULL
            THEN 'Unknown'

        WHEN
            CAST(product_length_cm AS BIGINT)
            * CAST(product_height_cm AS BIGINT)
            * CAST(product_width_cm AS BIGINT) < 5000
            THEN 'Small'

        WHEN
            CAST(product_length_cm AS BIGINT)
            * CAST(product_height_cm AS BIGINT)
            * CAST(product_width_cm AS BIGINT) < 20000
            THEN 'Medium'

        ELSE 'Large'
    END AS SizeCategory,

    CAST(1 AS BIT) AS IsActive,
    SYSUTCDATETIME() AS LoadTimestamp

FROM [LH_Olist_Medallion].[silver].[products]

WHERE product_id IS NOT NULL
  AND TRIM(product_id) <> '';
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Total rows and unique Product IDs
-- These values must be equal
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalDimensionRows,
    COUNT_BIG(DISTINCT ProductID) AS UniqueProductIDs
FROM gold.DimProduct;
GO

---------------------------------------------------------------
-- CHECK 2: Silver versus Gold
-- Gold excludes the Unknown product
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(DISTINCT product_id)
        FROM [LH_Olist_Medallion].[silver].[products]
        WHERE product_id IS NOT NULL
          AND TRIM(product_id) <> ''
    ) AS SilverProductCount,

    (
        SELECT COUNT_BIG(*)
        FROM gold.DimProduct
        WHERE ProductKey <> 0
    ) AS GoldKnownProductCount;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate Product IDs
-- Must return zero rows
---------------------------------------------------------------

SELECT
    ProductID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimProduct
GROUP BY ProductID
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Missing Product IDs
-- Must return zero
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS MissingProductIDCount
FROM gold.DimProduct
WHERE ProductID IS NULL
   OR TRIM(ProductID) = '';
GO

---------------------------------------------------------------
-- CHECK 5: Translation status distribution
---------------------------------------------------------------

SELECT
    CategoryTranslationStatus,
    COUNT_BIG(*) AS ProductCount
FROM gold.DimProduct
GROUP BY CategoryTranslationStatus
ORDER BY ProductCount DESC;
GO

---------------------------------------------------------------
-- CHECK 6: Product category distribution
---------------------------------------------------------------

SELECT TOP 20
    CategoryNameEnglish,
    COUNT_BIG(*) AS ProductCount
FROM gold.DimProduct
WHERE ProductKey <> 0
GROUP BY CategoryNameEnglish
ORDER BY ProductCount DESC;
GO

---------------------------------------------------------------
-- CHECK 7: Product size and weight segmentation
---------------------------------------------------------------

SELECT
    SizeCategory,
    WeightCategory,
    COUNT_BIG(*) AS ProductCount
FROM gold.DimProduct
GROUP BY
    SizeCategory,
    WeightCategory
ORDER BY ProductCount DESC;
GO

---------------------------------------------------------------
-- CHECK 8: Preview
---------------------------------------------------------------

SELECT TOP 20
    ProductKey,
    ProductID,
    CategoryNamePortuguese,
    CategoryNameEnglish,
    ProductWeightG,
    ProductVolumeCM3,
    WeightCategory,
    SizeCategory,
    CategoryTranslationStatus
FROM gold.DimProduct
ORDER BY ProductKey;
GO

