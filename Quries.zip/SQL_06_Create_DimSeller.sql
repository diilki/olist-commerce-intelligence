/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_06_Create_DimSeller
  Purpose : Create and load the Gold seller dimension

  Grain   : One row per seller_id
  Method  : SCD Type 1 / current seller attributes
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create the dimension
---------------------------------------------------------------

IF OBJECT_ID('gold.DimSeller', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimSeller
    (
        SellerKey           BIGINT IDENTITY NOT NULL,
        SellerID            VARCHAR(50)      NOT NULL,
        SellerZipCodePrefix INT              NULL,
        SellerCity          VARCHAR(100)     NOT NULL,
        SellerState         CHAR(2)          NOT NULL,
        SellerRegion        VARCHAR(20)      NOT NULL,
        IsActive            BIT              NOT NULL,
        LoadTimestamp       DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the development load
---------------------------------------------------------------

DELETE FROM gold.DimSeller;
GO

---------------------------------------------------------------
-- STEP 3: Insert the Unknown seller
---------------------------------------------------------------

SET IDENTITY_INSERT gold.DimSeller ON;
GO

INSERT INTO gold.DimSeller
(
    SellerKey,
    SellerID,
    SellerZipCodePrefix,
    SellerCity,
    SellerState,
    SellerRegion,
    IsActive,
    LoadTimestamp
)
VALUES
(
    0,
    'UNKNOWN',
    NULL,
    'Unknown',
    'UN',
    'Unknown',
    CAST(1 AS BIT),
    SYSUTCDATETIME()
);
GO

SET IDENTITY_INSERT gold.DimSeller OFF;
GO

---------------------------------------------------------------
-- STEP 4: Load known sellers
---------------------------------------------------------------

INSERT INTO gold.DimSeller
(
    SellerID,
    SellerZipCodePrefix,
    SellerCity,
    SellerState,
    SellerRegion,
    IsActive,
    LoadTimestamp
)
SELECT
    TRIM(seller_id) AS SellerID,

    seller_zip_code_prefix AS SellerZipCodePrefix,

    COALESCE
    (
        NULLIF(TRIM(seller_city), ''),
        'Unknown'
    ) AS SellerCity,

    COALESCE
    (
        NULLIF(UPPER(TRIM(seller_state)), ''),
        'UN'
    ) AS SellerState,

    CASE
        -- North
        WHEN UPPER(TRIM(seller_state))
             IN ('AC', 'AP', 'AM', 'PA', 'RO', 'RR', 'TO')
            THEN 'North'

        -- Northeast
        WHEN UPPER(TRIM(seller_state))
             IN ('AL', 'BA', 'CE', 'MA', 'PB',
                 'PE', 'PI', 'RN', 'SE')
            THEN 'Northeast'

        -- Central-West
        WHEN UPPER(TRIM(seller_state))
             IN ('DF', 'GO', 'MT', 'MS')
            THEN 'Central-West'

        -- Southeast
        WHEN UPPER(TRIM(seller_state))
             IN ('ES', 'MG', 'RJ', 'SP')
            THEN 'Southeast'

        -- South
        WHEN UPPER(TRIM(seller_state))
             IN ('PR', 'RS', 'SC')
            THEN 'South'

        ELSE 'Unknown'
    END AS SellerRegion,

    CAST(1 AS BIT) AS IsActive,
    SYSUTCDATETIME() AS LoadTimestamp

FROM [LH_Olist_Medallion].[silver].[sellers]

WHERE seller_id IS NOT NULL
  AND TRIM(seller_id) <> '';
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Total rows and unique Seller IDs
-- These values must be equal
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalDimensionRows,
    COUNT_BIG(DISTINCT SellerID) AS UniqueSellerIDs
FROM gold.DimSeller;
GO

---------------------------------------------------------------
-- CHECK 2: Compare Silver and Gold
-- Gold count excludes the Unknown record
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(DISTINCT seller_id)
        FROM [LH_Olist_Medallion].[silver].[sellers]
        WHERE seller_id IS NOT NULL
          AND TRIM(seller_id) <> ''
    ) AS SilverSellerCount,

    (
        SELECT COUNT_BIG(*)
        FROM gold.DimSeller
        WHERE SellerKey <> 0
    ) AS GoldKnownSellerCount;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate Seller IDs
-- Must return zero rows
---------------------------------------------------------------

SELECT
    SellerID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimSeller
GROUP BY SellerID
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Missing Seller IDs
-- Must return zero
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS MissingSellerIDCount
FROM gold.DimSeller
WHERE SellerID IS NULL
   OR TRIM(SellerID) = '';
GO

---------------------------------------------------------------
-- CHECK 5: Seller distribution by region
---------------------------------------------------------------

SELECT
    SellerRegion,
    COUNT_BIG(*) AS SellerCount
FROM gold.DimSeller
GROUP BY SellerRegion
ORDER BY SellerCount DESC;
GO

---------------------------------------------------------------
-- CHECK 6: Seller distribution by state
---------------------------------------------------------------

SELECT
    SellerState,
    COUNT_BIG(*) AS SellerCount
FROM gold.DimSeller
WHERE SellerKey <> 0
GROUP BY SellerState
ORDER BY SellerCount DESC;
GO

---------------------------------------------------------------
-- CHECK 7: Preview
---------------------------------------------------------------

SELECT TOP 20
    SellerKey,
    SellerID,
    SellerZipCodePrefix,
    SellerCity,
    SellerState,
    SellerRegion,
    IsActive,
    LoadTimestamp
FROM gold.DimSeller
ORDER BY SellerKey;
GO