/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_07_Create_DimGeography
  Purpose : Create a conformed geography dimension

  Grain   : One row per geolocation_zip_code_prefix
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create the geography dimension
---------------------------------------------------------------

IF OBJECT_ID('gold.DimGeography', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimGeography
    (
        GeographyKey          BIGINT IDENTITY NOT NULL,
        ZipCodePrefix         INT              NULL,
        GeographyCity         VARCHAR(100)     NOT NULL,
        GeographyState        CHAR(2)          NOT NULL,
        GeographyRegion       VARCHAR(20)      NOT NULL,
        AverageLatitude       DECIMAL(10,7)    NULL,
        AverageLongitude      DECIMAL(10,7)    NULL,
        ObservationCount      BIGINT           NOT NULL,
        ValidCoordinateCount  BIGINT           NOT NULL,
        LocationVariantCount  INT              NOT NULL,
        GeographyStatus       VARCHAR(30)      NOT NULL,
        IsActive              BIT              NOT NULL,
        LoadTimestamp         DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the current development load
---------------------------------------------------------------

DELETE FROM gold.DimGeography;
GO

---------------------------------------------------------------
-- STEP 3: Insert the Unknown geography record
---------------------------------------------------------------

SET IDENTITY_INSERT gold.DimGeography ON;
GO

INSERT INTO gold.DimGeography
(
    GeographyKey,
    ZipCodePrefix,
    GeographyCity,
    GeographyState,
    GeographyRegion,
    AverageLatitude,
    AverageLongitude,
    ObservationCount,
    ValidCoordinateCount,
    LocationVariantCount,
    GeographyStatus,
    IsActive,
    LoadTimestamp
)
VALUES
(
    0,
    NULL,
    'Unknown',
    'UN',
    'Unknown',
    NULL,
    NULL,
    0,
    0,
    0,
    'Unknown',
    CAST(1 AS BIT),
    SYSUTCDATETIME()
);
GO

SET IDENTITY_INSERT gold.DimGeography OFF;
GO

---------------------------------------------------------------
-- STEP 4: Normalize Silver geolocation observations
---------------------------------------------------------------

WITH NormalizedGeography AS
(
    SELECT
        geolocation_zip_code_prefix AS ZipCodePrefix,

        COALESCE
        (
            NULLIF(TRIM(geolocation_city), ''),
            'Unknown'
        ) AS GeographyCity,

        COALESCE
        (
            NULLIF(UPPER(TRIM(geolocation_state)), ''),
            'UN'
        ) AS GeographyState,

        TRY_CAST
        (
            geolocation_lat AS DECIMAL(18,8)
        ) AS Latitude,

        TRY_CAST
        (
            geolocation_lng AS DECIMAL(18,8)
        ) AS Longitude

    FROM [LH_Olist_Medallion].[silver].[geolocation]

    WHERE geolocation_zip_code_prefix IS NOT NULL
),

---------------------------------------------------------------
-- STEP 5: Count each city/state combination for each ZIP
---------------------------------------------------------------

LocationFrequency AS
(
    SELECT
        ZipCodePrefix,
        GeographyCity,
        GeographyState,
        COUNT_BIG(*) AS LocationFrequency
    FROM NormalizedGeography
    GROUP BY
        ZipCodePrefix,
        GeographyCity,
        GeographyState
),

---------------------------------------------------------------
-- STEP 6: Rank candidate locations
--
-- Row 1 is the most frequently recorded city/state combination
-- for the ZIP-code prefix.
---------------------------------------------------------------

RankedLocations AS
(
    SELECT
        ZipCodePrefix,
        GeographyCity,
        GeographyState,
        LocationFrequency,

        ROW_NUMBER() OVER
        (
            PARTITION BY ZipCodePrefix
            ORDER BY
                LocationFrequency DESC,
                GeographyState,
                GeographyCity
        ) AS LocationRank

    FROM LocationFrequency
),

---------------------------------------------------------------
-- STEP 7: Summarize coordinates and observation quality
---------------------------------------------------------------

CoordinateSummary AS
(
    SELECT
        ZipCodePrefix,

        CAST
        (
            AVG(Latitude)
            AS DECIMAL(10,7)
        ) AS AverageLatitude,

        CAST
        (
            AVG(Longitude)
            AS DECIMAL(10,7)
        ) AS AverageLongitude,

        COUNT_BIG(*) AS ObservationCount,

        COUNT_BIG
        (
            CASE
                WHEN Latitude IS NOT NULL
                 AND Longitude IS NOT NULL
                    THEN 1
            END
        ) AS ValidCoordinateCount

    FROM NormalizedGeography
    GROUP BY ZipCodePrefix
),

---------------------------------------------------------------
-- STEP 8: Count city/state variations per ZIP
---------------------------------------------------------------

VariantSummary AS
(
    SELECT
        ZipCodePrefix,
        CAST(COUNT_BIG(*) AS INT) AS LocationVariantCount
    FROM LocationFrequency
    GROUP BY ZipCodePrefix
)

---------------------------------------------------------------
-- STEP 9: Load one geography row per ZIP-code prefix
---------------------------------------------------------------

INSERT INTO gold.DimGeography
(
    ZipCodePrefix,
    GeographyCity,
    GeographyState,
    GeographyRegion,
    AverageLatitude,
    AverageLongitude,
    ObservationCount,
    ValidCoordinateCount,
    LocationVariantCount,
    GeographyStatus,
    IsActive,
    LoadTimestamp
)
SELECT
    r.ZipCodePrefix,
    r.GeographyCity,
    r.GeographyState,

    CASE
        -- North
        WHEN r.GeographyState
             IN ('AC', 'AP', 'AM', 'PA', 'RO', 'RR', 'TO')
            THEN 'North'

        -- Northeast
        WHEN r.GeographyState
             IN ('AL', 'BA', 'CE', 'MA', 'PB',
                 'PE', 'PI', 'RN', 'SE')
            THEN 'Northeast'

        -- Central-West
        WHEN r.GeographyState
             IN ('DF', 'GO', 'MT', 'MS')
            THEN 'Central-West'

        -- Southeast
        WHEN r.GeographyState
             IN ('ES', 'MG', 'RJ', 'SP')
            THEN 'Southeast'

        -- South
        WHEN r.GeographyState
             IN ('PR', 'RS', 'SC')
            THEN 'South'

        ELSE 'Unknown'
    END AS GeographyRegion,

    c.AverageLatitude,
    c.AverageLongitude,
    c.ObservationCount,
    c.ValidCoordinateCount,
    v.LocationVariantCount,

    CASE
        WHEN c.ValidCoordinateCount = 0
            THEN 'Missing coordinates'

        WHEN v.LocationVariantCount = 1
            THEN 'Consistent location'

        ELSE 'Multiple location variants'
    END AS GeographyStatus,

    CAST(1 AS BIT) AS IsActive,
    SYSUTCDATETIME() AS LoadTimestamp

FROM RankedLocations AS r

INNER JOIN CoordinateSummary AS c
    ON r.ZipCodePrefix = c.ZipCodePrefix

INNER JOIN VariantSummary AS v
    ON r.ZipCodePrefix = v.ZipCodePrefix

WHERE r.LocationRank = 1;
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Gold row and key statistics
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalDimensionRows,

    COUNT_BIG
    (
        CASE
            WHEN GeographyKey <> 0 THEN 1
        END
    ) AS KnownGeographyRows,

    COUNT_BIG(DISTINCT ZipCodePrefix)
        AS UniqueKnownZipCodes

FROM gold.DimGeography;
GO

---------------------------------------------------------------
-- CHECK 2: Silver versus Gold unique ZIP prefixes
-- These values must be equal
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG
        (
            DISTINCT geolocation_zip_code_prefix
        )
        FROM [LH_Olist_Medallion].[silver].[geolocation]
        WHERE geolocation_zip_code_prefix IS NOT NULL
    ) AS SilverUniqueZipCodes,

    (
        SELECT COUNT_BIG(*)
        FROM gold.DimGeography
        WHERE GeographyKey <> 0
    ) AS GoldKnownZipCodes;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate ZIP-code prefixes
-- Must return zero rows
---------------------------------------------------------------

SELECT
    ZipCodePrefix,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimGeography
WHERE GeographyKey <> 0
GROUP BY ZipCodePrefix
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Invalid coordinate ranges
-- Must return zero
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS InvalidCoordinateCount
FROM gold.DimGeography
WHERE GeographyKey <> 0
  AND
  (
       AverageLatitude NOT BETWEEN -90 AND 90
       OR AverageLongitude NOT BETWEEN -180 AND 180
  );
GO

---------------------------------------------------------------
-- CHECK 5: Confirm all Silver observations were summarized
--
-- Both values should equal 738,332.
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(*)
        FROM [LH_Olist_Medallion].[silver].[geolocation]
        WHERE geolocation_zip_code_prefix IS NOT NULL
    ) AS SilverObservationCount,

    (
        SELECT SUM(ObservationCount)
        FROM gold.DimGeography
        WHERE GeographyKey <> 0
    ) AS GoldSummarizedObservationCount;
GO

---------------------------------------------------------------
-- CHECK 6: Geography-quality distribution
---------------------------------------------------------------

SELECT
    GeographyStatus,
    COUNT_BIG(*) AS GeographyCount
FROM gold.DimGeography
GROUP BY GeographyStatus
ORDER BY GeographyCount DESC;
GO

---------------------------------------------------------------
-- CHECK 7: Region distribution
---------------------------------------------------------------

SELECT
    GeographyRegion,
    COUNT_BIG(*) AS GeographyCount
FROM gold.DimGeography
GROUP BY GeographyRegion
ORDER BY GeographyCount DESC;
GO

---------------------------------------------------------------
-- CHECK 8: Preview
---------------------------------------------------------------

SELECT TOP 20
    GeographyKey,
    ZipCodePrefix,
    GeographyCity,
    GeographyState,
    GeographyRegion,
    AverageLatitude,
    AverageLongitude,
    ObservationCount,
    LocationVariantCount,
    GeographyStatus
FROM gold.DimGeography
ORDER BY ObservationCount DESC;
GO