/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_08_Create_Reference_Dimensions
  Purpose : Create Order Status and Payment Type dimensions
==============================================================*/

/*==============================================================
  PART A: ORDER STATUS DIMENSION
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create DimOrderStatus
---------------------------------------------------------------

IF OBJECT_ID('gold.DimOrderStatus', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimOrderStatus
    (
        OrderStatusKey   SMALLINT    NOT NULL,
        OrderStatusCode  VARCHAR(30) NOT NULL,
        OrderStatusName  VARCHAR(50) NOT NULL,
        StatusGroup      VARCHAR(30) NOT NULL,
        IsTerminalStatus BIT         NOT NULL,
        StatusSortOrder  SMALLINT    NOT NULL,
        LoadTimestamp    DATETIME2(6) NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear existing development records
---------------------------------------------------------------

DELETE FROM gold.DimOrderStatus;
GO

---------------------------------------------------------------
-- STEP 3: Load deterministic order-status records
---------------------------------------------------------------

INSERT INTO gold.DimOrderStatus
(
    OrderStatusKey,
    OrderStatusCode,
    OrderStatusName,
    StatusGroup,
    IsTerminalStatus,
    StatusSortOrder,
    LoadTimestamp
)
VALUES
(
    0,
    'unknown',
    'Unknown',
    'Unknown',
    CAST(0 AS BIT),
    0,
    SYSUTCDATETIME()
),
(
    1,
    'created',
    'Created',
    'Open',
    CAST(0 AS BIT),
    1,
    SYSUTCDATETIME()
),
(
    2,
    'approved',
    'Approved',
    'In Progress',
    CAST(0 AS BIT),
    2,
    SYSUTCDATETIME()
),
(
    3,
    'invoiced',
    'Invoiced',
    'In Progress',
    CAST(0 AS BIT),
    3,
    SYSUTCDATETIME()
),
(
    4,
    'processing',
    'Processing',
    'In Progress',
    CAST(0 AS BIT),
    4,
    SYSUTCDATETIME()
),
(
    5,
    'shipped',
    'Shipped',
    'In Progress',
    CAST(0 AS BIT),
    5,
    SYSUTCDATETIME()
),
(
    6,
    'delivered',
    'Delivered',
    'Completed',
    CAST(1 AS BIT),
    6,
    SYSUTCDATETIME()
),
(
    7,
    'canceled',
    'Canceled',
    'Exception',
    CAST(1 AS BIT),
    7,
    SYSUTCDATETIME()
),
(
    8,
    'unavailable',
    'Unavailable',
    'Exception',
    CAST(1 AS BIT),
    8,
    SYSUTCDATETIME()
);
GO

/*==============================================================
  PART B: PAYMENT TYPE DIMENSION
==============================================================*/

---------------------------------------------------------------
-- STEP 4: Create DimPaymentType
---------------------------------------------------------------

IF OBJECT_ID('gold.DimPaymentType', 'U') IS NULL
BEGIN
    CREATE TABLE gold.DimPaymentType
    (
        PaymentTypeKey   SMALLINT     NOT NULL,
        PaymentTypeCode  VARCHAR(30)  NOT NULL,
        PaymentTypeName  VARCHAR(50)  NOT NULL,
        PaymentCategory  VARCHAR(30)  NOT NULL,
        IsCardPayment    BIT          NOT NULL,
        PaymentSortOrder SMALLINT     NOT NULL,
        LoadTimestamp    DATETIME2(6) NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 5: Clear existing development records
---------------------------------------------------------------

DELETE FROM gold.DimPaymentType;
GO

---------------------------------------------------------------
-- STEP 6: Load deterministic payment-type records
---------------------------------------------------------------

INSERT INTO gold.DimPaymentType
(
    PaymentTypeKey,
    PaymentTypeCode,
    PaymentTypeName,
    PaymentCategory,
    IsCardPayment,
    PaymentSortOrder,
    LoadTimestamp
)
VALUES
(
    0,
    'unknown',
    'Unknown',
    'Unknown',
    CAST(0 AS BIT),
    0,
    SYSUTCDATETIME()
),
(
    1,
    'credit_card',
    'Credit Card',
    'Card',
    CAST(1 AS BIT),
    1,
    SYSUTCDATETIME()
),
(
    2,
    'boleto',
    'Boleto',
    'Bank Slip',
    CAST(0 AS BIT),
    2,
    SYSUTCDATETIME()
),
(
    3,
    'voucher',
    'Voucher',
    'Voucher',
    CAST(0 AS BIT),
    3,
    SYSUTCDATETIME()
),
(
    4,
    'debit_card',
    'Debit Card',
    'Card',
    CAST(1 AS BIT),
    4,
    SYSUTCDATETIME()
),
(
    5,
    'not_defined',
    'Not Defined',
    'Unknown',
    CAST(0 AS BIT),
    5,
    SYSUTCDATETIME()
);
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Reference dimension counts
---------------------------------------------------------------

SELECT
    (SELECT COUNT_BIG(*) FROM gold.DimOrderStatus)
        AS OrderStatusRows,

    (SELECT COUNT_BIG(*) FROM gold.DimPaymentType)
        AS PaymentTypeRows;
GO

---------------------------------------------------------------
-- CHECK 2: Duplicate order-status keys or codes
-- Both sections must return zero rows
---------------------------------------------------------------

SELECT
    OrderStatusKey,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimOrderStatus
GROUP BY OrderStatusKey
HAVING COUNT_BIG(*) > 1;
GO

SELECT
    OrderStatusCode,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimOrderStatus
GROUP BY OrderStatusCode
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate payment keys or codes
-- Both sections must return zero rows
---------------------------------------------------------------

SELECT
    PaymentTypeKey,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimPaymentType
GROUP BY PaymentTypeKey
HAVING COUNT_BIG(*) > 1;
GO

SELECT
    PaymentTypeCode,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.DimPaymentType
GROUP BY PaymentTypeCode
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Unmapped Silver order statuses
-- Must return zero rows
---------------------------------------------------------------

WITH SilverStatuses AS
(
    SELECT DISTINCT
        COALESCE
        (
            NULLIF(LOWER(TRIM(order_status)), ''),
            'unknown'
        ) AS OrderStatusCode
    FROM [LH_Olist_Medallion].[silver].[orders]
)
SELECT
    s.OrderStatusCode AS UnmappedOrderStatus
FROM SilverStatuses AS s
LEFT JOIN gold.DimOrderStatus AS d
    ON s.OrderStatusCode = d.OrderStatusCode
WHERE d.OrderStatusKey IS NULL;
GO

---------------------------------------------------------------
-- CHECK 5: Unmapped Silver payment types
-- Must return zero rows
---------------------------------------------------------------

WITH SilverPaymentTypes AS
(
    SELECT DISTINCT
        COALESCE
        (
            NULLIF(LOWER(TRIM(payment_type)), ''),
            'unknown'
        ) AS PaymentTypeCode
    FROM [LH_Olist_Medallion].[silver].[order_payments]
)
SELECT
    p.PaymentTypeCode AS UnmappedPaymentType
FROM SilverPaymentTypes AS p
LEFT JOIN gold.DimPaymentType AS d
    ON p.PaymentTypeCode = d.PaymentTypeCode
WHERE d.PaymentTypeKey IS NULL;
GO

---------------------------------------------------------------
-- CHECK 6: Preview Order Status dimension
---------------------------------------------------------------

SELECT
    OrderStatusKey,
    OrderStatusCode,
    OrderStatusName,
    StatusGroup,
    IsTerminalStatus,
    StatusSortOrder
FROM gold.DimOrderStatus
ORDER BY StatusSortOrder;
GO

---------------------------------------------------------------
-- CHECK 7: Preview Payment Type dimension
---------------------------------------------------------------

SELECT
    PaymentTypeKey,
    PaymentTypeCode,
    PaymentTypeName,
    PaymentCategory,
    IsCardPayment,
    PaymentSortOrder
FROM gold.DimPaymentType
ORDER BY PaymentSortOrder;
GO