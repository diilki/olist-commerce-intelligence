/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_09_Create_FactOrders
  Purpose : Create the order-level analytical fact table

  Grain   : One row per order_id
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create FactOrders
---------------------------------------------------------------

IF OBJECT_ID('gold.FactOrders', 'U') IS NULL
BEGIN
    CREATE TABLE gold.FactOrders
    (
        FactOrderKey                 BIGINT IDENTITY NOT NULL,
        OrderID                      VARCHAR(50)      NOT NULL,

        -- Dimension keys
        CustomerKey                  BIGINT           NOT NULL,
        CustomerGeographyKey         BIGINT           NOT NULL,
        OrderStatusKey               SMALLINT         NOT NULL,
        PurchaseDateKey              INT              NOT NULL,
        ApprovalDateKey              INT              NOT NULL,
        CarrierDateKey               INT              NOT NULL,
        DeliveredDateKey             INT              NOT NULL,
        EstimatedDeliveryDateKey     INT              NOT NULL,

        -- Original lifecycle timestamps
        OrderPurchaseTimestamp       DATETIME2(6)     NOT NULL,
        OrderApprovedTimestamp       DATETIME2(6)     NULL,
        CarrierDeliveryTimestamp     DATETIME2(6)     NULL,
        CustomerDeliveryTimestamp    DATETIME2(6)     NULL,
        EstimatedDeliveryTimestamp   DATETIME2(6)     NULL,

        -- Order-item measures
        OrderItemCount               INT              NOT NULL,
        DistinctProductCount         INT              NOT NULL,
        DistinctSellerCount          INT              NOT NULL,
        ProductValue                 DECIMAL(18,2)    NOT NULL,
        FreightValue                 DECIMAL(18,2)    NOT NULL,
        GrossOrderValue              DECIMAL(18,2)    NOT NULL,

        -- Payment summaries
        PaymentTransactionCount      INT              NOT NULL,
        PaymentTotalValue            DECIMAL(18,2)    NOT NULL,
        MaximumInstallments          INT              NULL,

        -- Review summaries
        ReviewCount                  INT              NOT NULL,
        AverageReviewScore           DECIMAL(5,2)     NULL,

        -- Lifecycle measures
        PurchaseToApprovalHours      INT              NULL,
        ApprovalToCarrierHours       INT              NULL,
        CarrierToDeliveryDays        INT              NULL,
        PurchaseToDeliveryDays       INT              NULL,
        DeliveryVarianceDays         INT              NULL,

        -- Business flags
        IsDelivered                  BIT              NOT NULL,
        IsCanceled                   BIT              NOT NULL,
        IsLateDelivery               BIT              NULL,

        LoadTimestamp                DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the development load
---------------------------------------------------------------

DELETE FROM gold.FactOrders;
GO

---------------------------------------------------------------
-- STEP 3: Aggregate order items before joining
---------------------------------------------------------------

WITH ItemSummary AS
(
    SELECT
        order_id,

        CAST(COUNT_BIG(*) AS INT)
            AS OrderItemCount,

        COUNT(DISTINCT product_id)
            AS DistinctProductCount,

        COUNT(DISTINCT seller_id)
            AS DistinctSellerCount,

        CAST
        (
            SUM(CAST(price AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        ) AS ProductValue,

        CAST
        (
            SUM(CAST(freight_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        ) AS FreightValue

    FROM [LH_Olist_Medallion].[silver].[order_items]
    GROUP BY order_id
),

---------------------------------------------------------------
-- STEP 4: Aggregate payments before joining
---------------------------------------------------------------

PaymentSummary AS
(
    SELECT
        order_id,

        CAST(COUNT_BIG(*) AS INT)
            AS PaymentTransactionCount,

        CAST
        (
            SUM(CAST(payment_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        ) AS PaymentTotalValue,

        MAX(payment_installments)
            AS MaximumInstallments

    FROM [LH_Olist_Medallion].[silver].[order_payments]
    GROUP BY order_id
),

---------------------------------------------------------------
-- STEP 5: Aggregate reviews before joining
---------------------------------------------------------------

ReviewSummary AS
(
    SELECT
        order_id,

        CAST(COUNT_BIG(*) AS INT)
            AS ReviewCount,

        CAST
        (
            AVG(CAST(review_score AS DECIMAL(5,2)))
            AS DECIMAL(5,2)
        ) AS AverageReviewScore

    FROM [LH_Olist_Medallion].[silver].[order_reviews]
    GROUP BY order_id
),

---------------------------------------------------------------
-- STEP 6: Prepare one source record per order
---------------------------------------------------------------

OrderSource AS
(
    SELECT
        o.order_id,
        o.customer_id,
        o.order_status,
        o.order_purchase_timestamp,
        o.order_approved_at,
        o.order_delivered_carrier_date,
        o.order_delivered_customer_date,
        o.order_estimated_delivery_date,

        c.customer_unique_id,
        c.customer_zip_code_prefix

    FROM [LH_Olist_Medallion].[silver].[orders] AS o

    LEFT JOIN [LH_Olist_Medallion].[silver].[customers] AS c
        ON o.customer_id = c.customer_id
)

---------------------------------------------------------------
-- STEP 7: Load FactOrders
---------------------------------------------------------------

INSERT INTO gold.FactOrders
(
    OrderID,
    CustomerKey,
    CustomerGeographyKey,
    OrderStatusKey,
    PurchaseDateKey,
    ApprovalDateKey,
    CarrierDateKey,
    DeliveredDateKey,
    EstimatedDeliveryDateKey,
    OrderPurchaseTimestamp,
    OrderApprovedTimestamp,
    CarrierDeliveryTimestamp,
    CustomerDeliveryTimestamp,
    EstimatedDeliveryTimestamp,
    OrderItemCount,
    DistinctProductCount,
    DistinctSellerCount,
    ProductValue,
    FreightValue,
    GrossOrderValue,
    PaymentTransactionCount,
    PaymentTotalValue,
    MaximumInstallments,
    ReviewCount,
    AverageReviewScore,
    PurchaseToApprovalHours,
    ApprovalToCarrierHours,
    CarrierToDeliveryDays,
    PurchaseToDeliveryDays,
    DeliveryVarianceDays,
    IsDelivered,
    IsCanceled,
    IsLateDelivery,
    LoadTimestamp
)
SELECT
    o.order_id AS OrderID,

    COALESCE(dc.CustomerKey, 0)
        AS CustomerKey,

    COALESCE(dg.GeographyKey, 0)
        AS CustomerGeographyKey,

    COALESCE(ds.OrderStatusKey, 0)
        AS OrderStatusKey,

    COALESCE(purchaseDate.DateKey, 0)
        AS PurchaseDateKey,

    COALESCE(approvalDate.DateKey, 0)
        AS ApprovalDateKey,

    COALESCE(carrierDate.DateKey, 0)
        AS CarrierDateKey,

    COALESCE(deliveredDate.DateKey, 0)
        AS DeliveredDateKey,

    COALESCE(estimatedDate.DateKey, 0)
        AS EstimatedDeliveryDateKey,

    o.order_purchase_timestamp,
    o.order_approved_at,
    o.order_delivered_carrier_date,
    o.order_delivered_customer_date,
    o.order_estimated_delivery_date,

    COALESCE(i.OrderItemCount, 0),
    COALESCE(i.DistinctProductCount, 0),
    COALESCE(i.DistinctSellerCount, 0),

    COALESCE
    (
        i.ProductValue,
        CAST(0 AS DECIMAL(18,2))
    ) AS ProductValue,

    COALESCE
    (
        i.FreightValue,
        CAST(0 AS DECIMAL(18,2))
    ) AS FreightValue,

    COALESCE(i.ProductValue, 0)
        + COALESCE(i.FreightValue, 0)
        AS GrossOrderValue,

    COALESCE(p.PaymentTransactionCount, 0),

    COALESCE
    (
        p.PaymentTotalValue,
        CAST(0 AS DECIMAL(18,2))
    ) AS PaymentTotalValue,

    p.MaximumInstallments,

    COALESCE(r.ReviewCount, 0),
    r.AverageReviewScore,

    CASE
        WHEN o.order_approved_at IS NOT NULL
        THEN DATEDIFF
        (
            HOUR,
            o.order_purchase_timestamp,
            o.order_approved_at
        )
    END AS PurchaseToApprovalHours,

    CASE
        WHEN o.order_approved_at IS NOT NULL
         AND o.order_delivered_carrier_date IS NOT NULL
        THEN DATEDIFF
        (
            HOUR,
            o.order_approved_at,
            o.order_delivered_carrier_date
        )
    END AS ApprovalToCarrierHours,

    CASE
        WHEN o.order_delivered_carrier_date IS NOT NULL
         AND o.order_delivered_customer_date IS NOT NULL
        THEN DATEDIFF
        (
            DAY,
            o.order_delivered_carrier_date,
            o.order_delivered_customer_date
        )
    END AS CarrierToDeliveryDays,

    CASE
        WHEN o.order_delivered_customer_date IS NOT NULL
        THEN DATEDIFF
        (
            DAY,
            o.order_purchase_timestamp,
            o.order_delivered_customer_date
        )
    END AS PurchaseToDeliveryDays,

    CASE
        WHEN o.order_delivered_customer_date IS NOT NULL
         AND o.order_estimated_delivery_date IS NOT NULL
        THEN DATEDIFF
        (
            DAY,
            o.order_estimated_delivery_date,
            o.order_delivered_customer_date
        )
    END AS DeliveryVarianceDays,

    CASE
        WHEN LOWER(TRIM(o.order_status)) = 'delivered'
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsDelivered,

    CASE
        WHEN LOWER(TRIM(o.order_status)) = 'canceled'
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsCanceled,

    CASE
        WHEN o.order_delivered_customer_date IS NULL
          OR o.order_estimated_delivery_date IS NULL
            THEN NULL

        WHEN o.order_delivered_customer_date
             > o.order_estimated_delivery_date
            THEN CAST(1 AS BIT)

        ELSE CAST(0 AS BIT)
    END AS IsLateDelivery,

    SYSUTCDATETIME() AS LoadTimestamp

FROM OrderSource AS o

LEFT JOIN gold.DimCustomer AS dc
    ON TRIM(o.customer_unique_id) = dc.CustomerUniqueID

LEFT JOIN gold.DimGeography AS dg
    ON o.customer_zip_code_prefix = dg.ZipCodePrefix

LEFT JOIN gold.DimOrderStatus AS ds
    ON LOWER(TRIM(o.order_status)) = ds.OrderStatusCode

LEFT JOIN gold.DimDate AS purchaseDate
    ON CAST(o.order_purchase_timestamp AS DATE)
       = purchaseDate.FullDate

LEFT JOIN gold.DimDate AS approvalDate
    ON CAST(o.order_approved_at AS DATE)
       = approvalDate.FullDate

LEFT JOIN gold.DimDate AS carrierDate
    ON CAST(o.order_delivered_carrier_date AS DATE)
       = carrierDate.FullDate

LEFT JOIN gold.DimDate AS deliveredDate
    ON CAST(o.order_delivered_customer_date AS DATE)
       = deliveredDate.FullDate

LEFT JOIN gold.DimDate AS estimatedDate
    ON CAST(o.order_estimated_delivery_date AS DATE)
       = estimatedDate.FullDate

LEFT JOIN ItemSummary AS i
    ON o.order_id = i.order_id

LEFT JOIN PaymentSummary AS p
    ON o.order_id = p.order_id

LEFT JOIN ReviewSummary AS r
    ON o.order_id = r.order_id;
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Silver orders versus FactOrders
-- Both counts must be equal
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(*)
        FROM [LH_Olist_Medallion].[silver].[orders]
    ) AS SilverOrderCount,

    (
        SELECT COUNT_BIG(*)
        FROM gold.FactOrders
    ) AS FactOrderCount;
GO

---------------------------------------------------------------
-- CHECK 2: Fact grain validation
-- Both values must be equal
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS TotalFactRows,
    COUNT_BIG(DISTINCT OrderID) AS UniqueOrderIDs
FROM gold.FactOrders;
GO

---------------------------------------------------------------
-- CHECK 3: Duplicate Order IDs
-- Must return zero rows
---------------------------------------------------------------

SELECT
    OrderID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.FactOrders
GROUP BY OrderID
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 4: Unknown dimension keys
---------------------------------------------------------------

SELECT
    SUM(CASE WHEN CustomerKey = 0 THEN 1 ELSE 0 END)
        AS UnknownCustomers,

    SUM(CASE WHEN CustomerGeographyKey = 0 THEN 1 ELSE 0 END)
        AS UnknownGeographies,

    SUM(CASE WHEN OrderStatusKey = 0 THEN 1 ELSE 0 END)
        AS UnknownOrderStatuses,

    SUM(CASE WHEN PurchaseDateKey = 0 THEN 1 ELSE 0 END)
        AS UnknownPurchaseDates

FROM gold.FactOrders;
GO

---------------------------------------------------------------
-- CHECK 5: Product-value reconciliation
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(price AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_items]
    ) AS SilverProductValue,

    (
        SELECT CAST
        (
            SUM(ProductValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactOrders
    ) AS FactProductValue;
GO

---------------------------------------------------------------
-- CHECK 6: Freight-value reconciliation
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(freight_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_items]
    ) AS SilverFreightValue,

    (
        SELECT CAST
        (
            SUM(FreightValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactOrders
    ) AS FactFreightValue;
GO

---------------------------------------------------------------
-- CHECK 7: Payment-value reconciliation
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(payment_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_payments]
    ) AS SilverPaymentValue,

    (
        SELECT CAST
        (
            SUM(PaymentTotalValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactOrders
    ) AS FactPaymentValue;
GO

---------------------------------------------------------------
-- CHECK 8: Order-status distribution
---------------------------------------------------------------

SELECT
    ds.OrderStatusName,
    COUNT_BIG(*) AS OrderCount,
    SUM(f.ProductValue) AS ProductValue,
    SUM(f.FreightValue) AS FreightValue
FROM gold.FactOrders AS f
INNER JOIN gold.DimOrderStatus AS ds
    ON f.OrderStatusKey = ds.OrderStatusKey
GROUP BY ds.OrderStatusName
ORDER BY OrderCount DESC;
GO

---------------------------------------------------------------
-- CHECK 9: Delivery performance
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS DeliveredOrders,

    SUM
    (
        CASE WHEN IsLateDelivery = 1 THEN 1 ELSE 0 END
    ) AS LateDeliveries,

    CAST
    (
        AVG(CAST(PurchaseToDeliveryDays AS DECIMAL(10,2)))
        AS DECIMAL(10,2)
    ) AS AverageDeliveryDays

FROM gold.FactOrders
WHERE IsDelivered = 1;
GO

---------------------------------------------------------------
-- CHECK 10: Preview
---------------------------------------------------------------

SELECT TOP 20
    FactOrderKey,
    OrderID,
    CustomerKey,
    CustomerGeographyKey,
    OrderStatusKey,
    PurchaseDateKey,
    OrderItemCount,
    ProductValue,
    FreightValue,
    GrossOrderValue,
    PaymentTotalValue,
    AverageReviewScore,
    PurchaseToDeliveryDays,
    DeliveryVarianceDays,
    IsLateDelivery
FROM gold.FactOrders
ORDER BY FactOrderKey;
GO