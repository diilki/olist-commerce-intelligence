/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_10_Create_FactSales
  Purpose : Create the order-item sales fact table

  Grain   : One row per order_id + order_item_id
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create FactSales
---------------------------------------------------------------

IF OBJECT_ID('gold.FactSales', 'U') IS NULL
BEGIN
    CREATE TABLE gold.FactSales
    (
        FactSalesKey             BIGINT IDENTITY NOT NULL,

        -- Degenerate transaction identifiers
        OrderID                  VARCHAR(50)      NOT NULL,
        OrderItemID              INT              NOT NULL,

        -- Dimension keys
        CustomerKey              BIGINT           NOT NULL,
        CustomerGeographyKey     BIGINT           NOT NULL,
        ProductKey               BIGINT           NOT NULL,
        SellerKey                BIGINT           NOT NULL,
        OrderStatusKey           SMALLINT         NOT NULL,
        PurchaseDateKey          INT              NOT NULL,
        ShippingLimitDateKey     INT              NOT NULL,

        -- Operational timestamp
        ShippingLimitTimestamp   DATETIME2(6)     NULL,

        -- Additive measures
        ItemQuantity             SMALLINT         NOT NULL,
        ItemPrice                DECIMAL(18,2)    NOT NULL,
        FreightValue             DECIMAL(18,2)    NOT NULL,
        GrossItemValue           DECIMAL(18,2)    NOT NULL,

        -- Derived measures
        FreightPercentage        DECIMAL(9,4)     NULL,
        IsFreightGreaterThanPrice BIT             NOT NULL,

        LoadTimestamp            DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the development load
---------------------------------------------------------------

DELETE FROM gold.FactSales;
GO

---------------------------------------------------------------
-- STEP 3: Prepare order-level context
---------------------------------------------------------------

WITH OrderContext AS
(
    SELECT
        o.order_id,
        o.order_status,
        o.order_purchase_timestamp,

        c.customer_unique_id,
        c.customer_zip_code_prefix

    FROM [LH_Olist_Medallion].[silver].[orders] AS o

    LEFT JOIN [LH_Olist_Medallion].[silver].[customers] AS c
        ON o.customer_id = c.customer_id
)

---------------------------------------------------------------
-- STEP 4: Load FactSales
---------------------------------------------------------------

INSERT INTO gold.FactSales
(
    OrderID,
    OrderItemID,
    CustomerKey,
    CustomerGeographyKey,
    ProductKey,
    SellerKey,
    OrderStatusKey,
    PurchaseDateKey,
    ShippingLimitDateKey,
    ShippingLimitTimestamp,
    ItemQuantity,
    ItemPrice,
    FreightValue,
    GrossItemValue,
    FreightPercentage,
    IsFreightGreaterThanPrice,
    LoadTimestamp
)
SELECT
    oi.order_id AS OrderID,
    oi.order_item_id AS OrderItemID,

    COALESCE(dc.CustomerKey, 0)
        AS CustomerKey,

    COALESCE(dg.GeographyKey, 0)
        AS CustomerGeographyKey,

    COALESCE(dp.ProductKey, 0)
        AS ProductKey,

    COALESCE(ds.SellerKey, 0)
        AS SellerKey,

    COALESCE(dos.OrderStatusKey, 0)
        AS OrderStatusKey,

    COALESCE(purchaseDate.DateKey, 0)
        AS PurchaseDateKey,

    COALESCE(shippingDate.DateKey, 0)
        AS ShippingLimitDateKey,

    oi.shipping_limit_date
        AS ShippingLimitTimestamp,

    CAST(1 AS SMALLINT)
        AS ItemQuantity,

    CAST(oi.price AS DECIMAL(18,2))
        AS ItemPrice,

    CAST(oi.freight_value AS DECIMAL(18,2))
        AS FreightValue,

    CAST
    (
        CAST(oi.price AS DECIMAL(18,2))
        + CAST(oi.freight_value AS DECIMAL(18,2))
        AS DECIMAL(18,2)
    ) AS GrossItemValue,

    CASE
        WHEN
            CAST(oi.price AS DECIMAL(18,2))
            + CAST(oi.freight_value AS DECIMAL(18,2)) = 0
        THEN CAST(0 AS DECIMAL(9,4))

        ELSE CAST
        (
            (
                CAST(oi.freight_value AS DECIMAL(18,4))
                * 100
            )
            /
            NULLIF
            (
                CAST(oi.price AS DECIMAL(18,4))
                + CAST(oi.freight_value AS DECIMAL(18,4)),
                0
            )
            AS DECIMAL(9,4)
        )
    END AS FreightPercentage,

    CASE
        WHEN CAST(oi.freight_value AS DECIMAL(18,2))
             > CAST(oi.price AS DECIMAL(18,2))
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsFreightGreaterThanPrice,

    SYSUTCDATETIME() AS LoadTimestamp

FROM [LH_Olist_Medallion].[silver].[order_items] AS oi

LEFT JOIN OrderContext AS oc
    ON oi.order_id = oc.order_id

LEFT JOIN gold.DimCustomer AS dc
    ON TRIM(oc.customer_unique_id) = dc.CustomerUniqueID

LEFT JOIN gold.DimGeography AS dg
    ON oc.customer_zip_code_prefix = dg.ZipCodePrefix

LEFT JOIN gold.DimProduct AS dp
    ON TRIM(oi.product_id) = dp.ProductID

LEFT JOIN gold.DimSeller AS ds
    ON TRIM(oi.seller_id) = ds.SellerID

LEFT JOIN gold.DimOrderStatus AS dos
    ON LOWER(TRIM(oc.order_status)) = dos.OrderStatusCode

LEFT JOIN gold.DimDate AS purchaseDate
    ON CAST(oc.order_purchase_timestamp AS DATE)
       = purchaseDate.FullDate

LEFT JOIN gold.DimDate AS shippingDate
    ON CAST(oi.shipping_limit_date AS DATE)
       = shippingDate.FullDate;
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Silver item rows versus FactSales
-- Both counts must be equal
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(*)
        FROM [LH_Olist_Medallion].[silver].[order_items]
    ) AS SilverOrderItemCount,

    (
        SELECT COUNT_BIG(*)
        FROM gold.FactSales
    ) AS FactSalesCount;
GO

---------------------------------------------------------------
-- CHECK 2: Duplicate fact grain
-- Must return zero rows
---------------------------------------------------------------

SELECT
    OrderID,
    OrderItemID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.FactSales
GROUP BY
    OrderID,
    OrderItemID
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 3: Unknown dimension keys
---------------------------------------------------------------

SELECT
    SUM(CASE WHEN CustomerKey = 0 THEN 1 ELSE 0 END)
        AS UnknownCustomers,

    SUM(CASE WHEN CustomerGeographyKey = 0 THEN 1 ELSE 0 END)
        AS UnknownGeographies,

    SUM(CASE WHEN ProductKey = 0 THEN 1 ELSE 0 END)
        AS UnknownProducts,

    SUM(CASE WHEN SellerKey = 0 THEN 1 ELSE 0 END)
        AS UnknownSellers,

    SUM(CASE WHEN OrderStatusKey = 0 THEN 1 ELSE 0 END)
        AS UnknownOrderStatuses,

    SUM(CASE WHEN PurchaseDateKey = 0 THEN 1 ELSE 0 END)
        AS UnknownPurchaseDates,

    SUM(CASE WHEN ShippingLimitDateKey = 0 THEN 1 ELSE 0 END)
        AS UnknownShippingLimitDates

FROM gold.FactSales;
GO

---------------------------------------------------------------
-- CHECK 4: Product-value reconciliation
-- Silver and Gold must match
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(price AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_items]
    ) AS SilverProductValue,

    (
        SELECT CAST
        (
            SUM(ItemPrice)
            AS DECIMAL(18,2)
        )
        FROM gold.FactSales
    ) AS GoldProductValue;
GO

---------------------------------------------------------------
-- CHECK 5: Freight-value reconciliation
-- Silver and Gold must match
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(freight_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_items]
    ) AS SilverFreightValue,

    (
        SELECT CAST
        (
            SUM(FreightValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactSales
    ) AS GoldFreightValue;
GO

---------------------------------------------------------------
-- CHECK 6: Gross-value validation
--
-- Gross value must equal item price plus freight.
-- Must return zero invalid rows.
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS InvalidGrossValueRows
FROM gold.FactSales
WHERE GrossItemValue <> ItemPrice + FreightValue;
GO

---------------------------------------------------------------
-- CHECK 7: FactOrders versus FactSales reconciliation
---------------------------------------------------------------

SELECT
    (
        SELECT SUM(ProductValue)
        FROM gold.FactOrders
    ) AS FactOrdersProductValue,

    (
        SELECT SUM(ItemPrice)
        FROM gold.FactSales
    ) AS FactSalesProductValue,

    (
        SELECT SUM(FreightValue)
        FROM gold.FactOrders
    ) AS FactOrdersFreightValue,

    (
        SELECT SUM(FreightValue)
        FROM gold.FactSales
    ) AS FactSalesFreightValue;
GO

---------------------------------------------------------------
-- CHECK 8: Top product categories by product value
---------------------------------------------------------------

SELECT TOP 20
    dp.CategoryNameEnglish,
    COUNT_BIG(*) AS ItemsSold,
    SUM(fs.ItemPrice) AS ProductValue,
    SUM(fs.FreightValue) AS FreightValue,
    SUM(fs.GrossItemValue) AS GrossValue
FROM gold.FactSales AS fs
INNER JOIN gold.DimProduct AS dp
    ON fs.ProductKey = dp.ProductKey
WHERE fs.ProductKey <> 0
GROUP BY dp.CategoryNameEnglish
ORDER BY ProductValue DESC;
GO

---------------------------------------------------------------
-- CHECK 9: Top sellers
---------------------------------------------------------------

SELECT TOP 20
    ds.SellerID,
    ds.SellerState,
    ds.SellerRegion,
    COUNT_BIG(*) AS ItemsSold,
    SUM(fs.ItemPrice) AS ProductValue,
    SUM(fs.FreightValue) AS FreightValue
FROM gold.FactSales AS fs
INNER JOIN gold.DimSeller AS ds
    ON fs.SellerKey = ds.SellerKey
WHERE fs.SellerKey <> 0
GROUP BY
    ds.SellerID,
    ds.SellerState,
    ds.SellerRegion
ORDER BY ProductValue DESC;
GO

---------------------------------------------------------------
-- CHECK 10: Preview
---------------------------------------------------------------

SELECT TOP 20
    FactSalesKey,
    OrderID,
    OrderItemID,
    CustomerKey,
    ProductKey,
    SellerKey,
    PurchaseDateKey,
    ItemPrice,
    FreightValue,
    GrossItemValue,
    FreightPercentage
FROM gold.FactSales
ORDER BY FactSalesKey;
GO