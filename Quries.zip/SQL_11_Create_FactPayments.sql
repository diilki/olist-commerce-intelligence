/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_11_Create_FactPayments
  Purpose : Create the payment-transaction fact table

  Grain   : One row per order_id + payment_sequential
==============================================================*/

---------------------------------------------------------------
-- STEP 1: Create FactPayments
---------------------------------------------------------------

IF OBJECT_ID('gold.FactPayments', 'U') IS NULL
BEGIN
    CREATE TABLE gold.FactPayments
    (
        FactPaymentKey       BIGINT IDENTITY NOT NULL,

        -- Degenerate transaction identifiers
        OrderID              VARCHAR(50)      NOT NULL,
        PaymentSequence      INT              NOT NULL,

        -- Dimension keys
        CustomerKey          BIGINT           NOT NULL,
        CustomerGeographyKey BIGINT           NOT NULL,
        PaymentTypeKey       SMALLINT         NOT NULL,
        OrderStatusKey       SMALLINT         NOT NULL,
        PurchaseDateKey      INT              NOT NULL,

        -- Payment measures
        PaymentInstallments  INT              NOT NULL,
        PaymentValue         DECIMAL(18,2)    NOT NULL,
        EstimatedInstallmentValue DECIMAL(18,2) NULL,

        -- Business flags
        IsInstallmentPayment BIT              NOT NULL,
        IsMultiPaymentOrder  BIT              NOT NULL,

        LoadTimestamp        DATETIME2(6)     NOT NULL
    );
END;
GO

---------------------------------------------------------------
-- STEP 2: Clear the development load
---------------------------------------------------------------

DELETE FROM gold.FactPayments;
GO

---------------------------------------------------------------
-- STEP 3: Prepare order and customer context
---------------------------------------------------------------

WITH OrderContext AS
(
    SELECT
        o.order_id,
        o.order_status,
        o.order_purchase_timestamp,

        c.customer_unique_id,
        c.customer_zip_code_prefix

    FROM [LH_Olist_Medallion].[silver].[orders] AS o

    LEFT JOIN [LH_Olist_Medallion].[silver].[customers] AS c
        ON o.customer_id = c.customer_id
),

---------------------------------------------------------------
-- STEP 4: Determine how many payment rows each order has
---------------------------------------------------------------

PaymentCounts AS
(
    SELECT
        order_id,
        COUNT_BIG(*) AS PaymentRowCount
    FROM [LH_Olist_Medallion].[silver].[order_payments]
    GROUP BY order_id
)

---------------------------------------------------------------
-- STEP 5: Load FactPayments
---------------------------------------------------------------

INSERT INTO gold.FactPayments
(
    OrderID,
    PaymentSequence,
    CustomerKey,
    CustomerGeographyKey,
    PaymentTypeKey,
    OrderStatusKey,
    PurchaseDateKey,
    PaymentInstallments,
    PaymentValue,
    EstimatedInstallmentValue,
    IsInstallmentPayment,
    IsMultiPaymentOrder,
    LoadTimestamp
)
SELECT
    p.order_id AS OrderID,
    p.payment_sequential AS PaymentSequence,

    COALESCE(dc.CustomerKey, 0)
        AS CustomerKey,

    COALESCE(dg.GeographyKey, 0)
        AS CustomerGeographyKey,

    COALESCE(dpt.PaymentTypeKey, 0)
        AS PaymentTypeKey,

    COALESCE(dos.OrderStatusKey, 0)
        AS OrderStatusKey,

    COALESCE(dd.DateKey, 0)
        AS PurchaseDateKey,

    COALESCE(p.payment_installments, 0)
        AS PaymentInstallments,

    CAST(p.payment_value AS DECIMAL(18,2))
        AS PaymentValue,

    CASE
        WHEN p.payment_installments IS NULL
          OR p.payment_installments <= 0
            THEN NULL

        ELSE CAST
        (
            CAST(p.payment_value AS DECIMAL(18,4))
            / p.payment_installments
            AS DECIMAL(18,2)
        )
    END AS EstimatedInstallmentValue,

    CASE
        WHEN p.payment_installments > 1
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsInstallmentPayment,

    CASE
        WHEN pc.PaymentRowCount > 1
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsMultiPaymentOrder,

    SYSUTCDATETIME() AS LoadTimestamp

FROM [LH_Olist_Medallion].[silver].[order_payments] AS p

LEFT JOIN OrderContext AS oc
    ON p.order_id = oc.order_id

LEFT JOIN PaymentCounts AS pc
    ON p.order_id = pc.order_id

LEFT JOIN gold.DimCustomer AS dc
    ON TRIM(oc.customer_unique_id) = dc.CustomerUniqueID

LEFT JOIN gold.DimGeography AS dg
    ON oc.customer_zip_code_prefix = dg.ZipCodePrefix

LEFT JOIN gold.DimPaymentType AS dpt
    ON LOWER(TRIM(p.payment_type)) = dpt.PaymentTypeCode

LEFT JOIN gold.DimOrderStatus AS dos
    ON LOWER(TRIM(oc.order_status)) = dos.OrderStatusCode

LEFT JOIN gold.DimDate AS dd
    ON CAST(oc.order_purchase_timestamp AS DATE)
       = dd.FullDate;
GO

/*==============================================================
  QUALITY VALIDATION
==============================================================*/

---------------------------------------------------------------
-- CHECK 1: Silver payments versus FactPayments
-- Both values must be equal
---------------------------------------------------------------

SELECT
    (
        SELECT COUNT_BIG(*)
        FROM [LH_Olist_Medallion].[silver].[order_payments]
    ) AS SilverPaymentRows,

    (
        SELECT COUNT_BIG(*)
        FROM gold.FactPayments
    ) AS FactPaymentRows;
GO

---------------------------------------------------------------
-- CHECK 2: Duplicate payment grain
-- Must return zero rows
---------------------------------------------------------------

SELECT
    OrderID,
    PaymentSequence,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.FactPayments
GROUP BY
    OrderID,
    PaymentSequence
HAVING COUNT_BIG(*) > 1;
GO

---------------------------------------------------------------
-- CHECK 3: Unknown dimension keys
---------------------------------------------------------------

SELECT
    SUM(CASE WHEN CustomerKey = 0 THEN 1 ELSE 0 END)
        AS UnknownCustomers,

    SUM(CASE WHEN CustomerGeographyKey = 0 THEN 1 ELSE 0 END)
        AS UnknownGeographies,

    SUM(CASE WHEN PaymentTypeKey = 0 THEN 1 ELSE 0 END)
        AS UnknownPaymentTypes,

    SUM(CASE WHEN OrderStatusKey = 0 THEN 1 ELSE 0 END)
        AS UnknownOrderStatuses,

    SUM(CASE WHEN PurchaseDateKey = 0 THEN 1 ELSE 0 END)
        AS UnknownPurchaseDates

FROM gold.FactPayments;
GO

---------------------------------------------------------------
-- CHECK 4: Payment-value reconciliation
-- Silver and Gold must match
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(CAST(payment_value AS DECIMAL(18,2)))
            AS DECIMAL(18,2)
        )
        FROM [LH_Olist_Medallion].[silver].[order_payments]
    ) AS SilverPaymentValue,

    (
        SELECT CAST
        (
            SUM(PaymentValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactPayments
    ) AS GoldPaymentValue;
GO

---------------------------------------------------------------
-- CHECK 5: FactOrders versus FactPayments
-- Both totals must match
---------------------------------------------------------------

SELECT
    (
        SELECT CAST
        (
            SUM(PaymentTotalValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactOrders
    ) AS FactOrdersPaymentValue,

    (
        SELECT CAST
        (
            SUM(PaymentValue)
            AS DECIMAL(18,2)
        )
        FROM gold.FactPayments
    ) AS FactPaymentsValue;
GO

---------------------------------------------------------------
-- CHECK 6: Invalid payment values
-- Must return zero
---------------------------------------------------------------

SELECT
    COUNT_BIG(*) AS InvalidPaymentRows
FROM gold.FactPayments
WHERE PaymentValue < 0
   OR PaymentInstallments < 0;
GO

---------------------------------------------------------------
-- CHECK 7: Payment-type analysis
---------------------------------------------------------------

SELECT
    dpt.PaymentTypeName,
    dpt.PaymentCategory,
    COUNT_BIG(*) AS PaymentTransactions,
    COUNT_BIG(DISTINCT fp.OrderID) AS Orders,
    SUM(fp.PaymentValue) AS PaymentValue,
    AVG(CAST(fp.PaymentValue AS DECIMAL(18,2)))
        AS AveragePaymentValue
FROM gold.FactPayments AS fp
INNER JOIN gold.DimPaymentType AS dpt
    ON fp.PaymentTypeKey = dpt.PaymentTypeKey
GROUP BY
    dpt.PaymentTypeName,
    dpt.PaymentCategory
ORDER BY PaymentValue DESC;
GO

---------------------------------------------------------------
-- CHECK 8: Installment analysis
---------------------------------------------------------------

SELECT
    PaymentInstallments,
    COUNT_BIG(*) AS PaymentTransactions,
    SUM(PaymentValue) AS PaymentValue,
    AVG(CAST(PaymentValue AS DECIMAL(18,2)))
        AS AveragePaymentValue
FROM gold.FactPayments
GROUP BY PaymentInstallments
ORDER BY PaymentInstallments;
GO

---------------------------------------------------------------
-- CHECK 9: Multiple-payment-order analysis
---------------------------------------------------------------

SELECT
    IsMultiPaymentOrder,
    COUNT_BIG(DISTINCT OrderID) AS OrderCount,
    COUNT_BIG(*) AS PaymentTransactionCount,
    SUM(PaymentValue) AS PaymentValue
FROM gold.FactPayments
GROUP BY IsMultiPaymentOrder;
GO

---------------------------------------------------------------
-- CHECK 10: Preview
---------------------------------------------------------------

SELECT TOP 20
    FactPaymentKey,
    OrderID,
    PaymentSequence,
    CustomerKey,
    PaymentTypeKey,
    PurchaseDateKey,
    PaymentInstallments,
    PaymentValue,
    EstimatedInstallmentValue,
    IsInstallmentPayment,
    IsMultiPaymentOrder
FROM gold.FactPayments
ORDER BY FactPaymentKey;
GO