/*==============================================================
  Project : Olist Commerce Intelligence
  Script  : SQL_12_Create_FactReviews
  Purpose : Create and load the Gold customer-review fact table

  Grain:
  One row per ReviewID + OrderID
==============================================================*/


/*==============================================================
  1. CREATE THE FACT TABLE
==============================================================*/

IF OBJECT_ID('gold.FactReviews', 'U') IS NULL
BEGIN
    CREATE TABLE gold.FactReviews
    (
        ReviewFactKey          BIGINT IDENTITY NOT NULL,

        -- Degenerate business identifiers
        ReviewID               VARCHAR(50)  NOT NULL,
        OrderID                VARCHAR(50)  NOT NULL,

        -- Dimension keys
        CustomerKey            BIGINT       NOT NULL,
        CustomerGeographyKey   BIGINT       NOT NULL,
        OrderStatusKey         SMALLINT     NOT NULL,
        PurchaseDateKey        INT          NOT NULL,
        DeliveredDateKey       INT          NOT NULL,
        ReviewCreationDateKey  INT          NOT NULL,
        ReviewAnswerDateKey    INT          NOT NULL,

        -- Review measurements
        ReviewScore            SMALLINT     NOT NULL,
        ReviewCommentTitle     VARCHAR(500) NULL,
        ReviewCommentMessage   VARCHAR(4000) NULL,
        CommentLength          INT          NOT NULL,
        ResponseTimeHours      INT          NULL,

        -- Analysis flags
        HasCommentTitle        BIT          NOT NULL,
        HasCommentMessage      BIT          NOT NULL,
        IsPositiveReview       BIT          NOT NULL,
        IsNeutralReview        BIT          NOT NULL,
        IsNegativeReview       BIT          NOT NULL,

        -- ETL audit column
        LoadedAtUTC            DATETIME2(6) NOT NULL
    );
END;
GO


/*==============================================================
  2. MAKE THE SCRIPT REPEATABLE
==============================================================*/

DELETE FROM gold.FactReviews;
GO


/*==============================================================
  3. LOAD FACTREVIEWS
==============================================================*/

INSERT INTO gold.FactReviews
(
    ReviewID,
    OrderID,

    CustomerKey,
    CustomerGeographyKey,
    OrderStatusKey,

    PurchaseDateKey,
    DeliveredDateKey,
    ReviewCreationDateKey,
    ReviewAnswerDateKey,

    ReviewScore,
    ReviewCommentTitle,
    ReviewCommentMessage,
    CommentLength,
    ResponseTimeHours,

    HasCommentTitle,
    HasCommentMessage,
    IsPositiveReview,
    IsNeutralReview,
    IsNegativeReview,

    LoadedAtUTC
)
SELECT
    R.review_id AS ReviewID,
    R.order_id  AS OrderID,

    -- Obtain order-related dimensional keys from FactOrders
    COALESCE(O.CustomerKey, 0)
        AS CustomerKey,

    COALESCE(O.CustomerGeographyKey, 0)
        AS CustomerGeographyKey,

    COALESCE(O.OrderStatusKey, 0)
        AS OrderStatusKey,

    COALESCE(O.PurchaseDateKey, 0)
        AS PurchaseDateKey,

    COALESCE(O.DeliveredDateKey, 0)
        AS DeliveredDateKey,

    COALESCE(ReviewCreationDate.DateKey, 0)
        AS ReviewCreationDateKey,

    COALESCE(ReviewAnswerDate.DateKey, 0)
        AS ReviewAnswerDateKey,

    CAST(R.review_score AS SMALLINT)
        AS ReviewScore,

    NULLIF(
        TRIM(R.review_comment_title),
        ''
    ) AS ReviewCommentTitle,

    NULLIF(
        TRIM(R.review_comment_message),
        ''
    ) AS ReviewCommentMessage,

    CASE
        WHEN NULLIF(TRIM(R.review_comment_message), '') IS NULL
            THEN 0
        ELSE LEN(TRIM(R.review_comment_message))
    END AS CommentLength,

    CASE
        WHEN R.review_creation_date IS NOT NULL
         AND R.review_answer_timestamp IS NOT NULL
         AND R.review_answer_timestamp >= R.review_creation_date
        THEN DATEDIFF(
                 HOUR,
                 R.review_creation_date,
                 R.review_answer_timestamp
             )
        ELSE NULL
    END AS ResponseTimeHours,

    CASE
        WHEN NULLIF(TRIM(R.review_comment_title), '') IS NOT NULL
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS HasCommentTitle,

    CASE
        WHEN NULLIF(TRIM(R.review_comment_message), '') IS NOT NULL
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS HasCommentMessage,

    CASE
        WHEN R.review_score >= 4
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsPositiveReview,

    CASE
        WHEN R.review_score = 3
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsNeutralReview,

    CASE
        WHEN R.review_score <= 2
            THEN CAST(1 AS BIT)
        ELSE CAST(0 AS BIT)
    END AS IsNegativeReview,

    CAST(GETUTCDATE() AS DATETIME2(6))
        AS LoadedAtUTC

FROM [LH_Olist_Medallion].[silver].[order_reviews] AS R

LEFT JOIN gold.FactOrders AS O
    ON R.order_id = O.OrderID

LEFT JOIN gold.DimDate AS ReviewCreationDate
    ON ReviewCreationDate.FullDate =
       CAST(R.review_creation_date AS DATE)

LEFT JOIN gold.DimDate AS ReviewAnswerDate
    ON ReviewAnswerDate.FullDate =
       CAST(R.review_answer_timestamp AS DATE);
GO

/*==============================================================
  CHECK 1: Silver-to-Gold row reconciliation
==============================================================*/

SELECT
    (
        SELECT COUNT_BIG(*)
        FROM [LH_Olist_Medallion].[silver].[order_reviews]
    ) AS SilverReviewRows,

    (
        SELECT COUNT_BIG(*)
        FROM gold.FactReviews
    ) AS FactReviewRows;
GO


/*==============================================================
  CHECK 2: Duplicate grain
  Required result: zero rows
==============================================================*/

SELECT
    ReviewID,
    OrderID,
    COUNT_BIG(*) AS DuplicateCount
FROM gold.FactReviews
GROUP BY
    ReviewID,
    OrderID
HAVING COUNT_BIG(*) > 1;
GO


/*==============================================================
  CHECK 3: Invalid review scores
  Required result: 0
==============================================================*/

SELECT
    COUNT_BIG(*) AS InvalidReviewScoreCount
FROM gold.FactReviews
WHERE ReviewScore NOT BETWEEN 1 AND 5;
GO


/*==============================================================
  CHECK 4: Reviews without a matching order
==============================================================*/

SELECT
    COUNT_BIG(*) AS UnknownOrderCount
FROM gold.FactReviews
WHERE CustomerKey = 0
   OR OrderStatusKey = 0;
GO


/*==============================================================
  CHECK 5: Review-score distribution
==============================================================*/

SELECT
    ReviewScore,
    COUNT_BIG(*) AS ReviewCount,
    CAST(
        COUNT_BIG(*) * 100.0 /
        SUM(COUNT_BIG(*)) OVER ()
        AS DECIMAL(6,2)
    ) AS ReviewPercentage
FROM gold.FactReviews
GROUP BY ReviewScore
ORDER BY ReviewScore;
GO


/*==============================================================
  CHECK 6: Sentiment groups
==============================================================*/

SELECT
    SUM(CAST(IsPositiveReview AS BIGINT))
        AS PositiveReviews,

    SUM(CAST(IsNeutralReview AS BIGINT))
        AS NeutralReviews,

    SUM(CAST(IsNegativeReview AS BIGINT))
        AS NegativeReviews,

    AVG(CAST(ReviewScore AS DECIMAL(10,2)))
        AS AverageReviewScore
FROM gold.FactReviews;
GO


/*==============================================================
  CHECK 7: Comment analysis
==============================================================*/

SELECT
    COUNT_BIG(*) AS TotalReviews,

    SUM(CAST(HasCommentMessage AS BIGINT))
        AS ReviewsWithComments,

    AVG(CAST(CommentLength AS DECIMAL(10,2)))
        AS AverageCommentLength,

    AVG(CAST(ResponseTimeHours AS DECIMAL(18,2)))
        AS AverageResponseTimeHours
FROM gold.FactReviews;
GO


/*==============================================================
  CHECK 8: Preview
==============================================================*/

SELECT TOP 20 *
FROM gold.FactReviews
ORDER BY ReviewFactKey;
GO