SELECT
    S.name AS SchemaName,
    T.name AS TableName
FROM sys.tables AS T
INNER JOIN sys.schemas AS S
    ON T.schema_id = S.schema_id
WHERE S.name = 'gold'
ORDER BY T.name;
GO


SELECT
    'FactOrders' AS TestName,
    (SELECT COUNT_BIG(*)
     FROM [LH_Olist_Medallion].[silver].[orders])
        AS SilverRows,
    (SELECT COUNT_BIG(*)
     FROM gold.FactOrders)
        AS GoldRows,
    CASE
        WHEN
            (SELECT COUNT_BIG(*)
             FROM [LH_Olist_Medallion].[silver].[orders])
            =
            (SELECT COUNT_BIG(*)
             FROM gold.FactOrders)
        THEN 'PASS'
        ELSE 'FAIL'
    END AS TestStatus

UNION ALL

SELECT
    'FactSales',
    (SELECT COUNT_BIG(*)
     FROM [LH_Olist_Medallion].[silver].[order_items]),
    (SELECT COUNT_BIG(*)
     FROM gold.FactSales),
    CASE
        WHEN
            (SELECT COUNT_BIG(*)
             FROM [LH_Olist_Medallion].[silver].[order_items])
            =
            (SELECT COUNT_BIG(*)
             FROM gold.FactSales)
        THEN 'PASS'
        ELSE 'FAIL'
    END

UNION ALL

SELECT
    'FactPayments',
    (SELECT COUNT_BIG(*)
     FROM [LH_Olist_Medallion].[silver].[order_payments]),
    (SELECT COUNT_BIG(*)
     FROM gold.FactPayments),
    CASE
        WHEN
            (SELECT COUNT_BIG(*)
             FROM [LH_Olist_Medallion].[silver].[order_payments])
            =
            (SELECT COUNT_BIG(*)
             FROM gold.FactPayments)
        THEN 'PASS'
        ELSE 'FAIL'
    END

UNION ALL

SELECT
    'FactReviews',
    (SELECT COUNT_BIG(*)
     FROM [LH_Olist_Medallion].[silver].[order_reviews]),
    (SELECT COUNT_BIG(*)
     FROM gold.FactReviews),
    CASE
        WHEN
            (SELECT COUNT_BIG(*)
             FROM [LH_Olist_Medallion].[silver].[order_reviews])
            =
            (SELECT COUNT_BIG(*)
             FROM gold.FactReviews)
        THEN 'PASS'
        ELSE 'FAIL'
    END;
GO


SELECT
    COLUMN_NAME,
    DATA_TYPE,
    ORDINAL_POSITION
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME = 'FactPayments'
ORDER BY ORDINAL_POSITION;
GO

WITH QualityTests AS
(
    SELECT
        'FactOrders duplicate OrderID' AS TestName,
        COUNT_BIG(*) AS IssueCount
    FROM
    (
        SELECT OrderID
        FROM gold.FactOrders
        GROUP BY OrderID
        HAVING COUNT_BIG(*) > 1
    ) AS D

    UNION ALL

    SELECT
        'FactSales duplicate OrderID + OrderItemID',
        COUNT_BIG(*)
    FROM
    (
        SELECT
            OrderID,
            OrderItemID
        FROM gold.FactSales
        GROUP BY
            OrderID,
            OrderItemID
        HAVING COUNT_BIG(*) > 1
    ) AS D

    UNION ALL

    SELECT
        'FactPayments duplicate OrderID + PaymentSequence',
        COUNT_BIG(*)
    FROM
    (
        SELECT
            OrderID,
            PaymentSequence
        FROM gold.FactPayments
        GROUP BY
            OrderID,
            PaymentSequence
        HAVING COUNT_BIG(*) > 1
    ) AS D

    UNION ALL

    SELECT
        'FactReviews duplicate ReviewID + OrderID',
        COUNT_BIG(*)
    FROM
    (
        SELECT
            ReviewID,
            OrderID
        FROM gold.FactReviews
        GROUP BY
            ReviewID,
            OrderID
        HAVING COUNT_BIG(*) > 1
    ) AS D
)
SELECT
    TestName,
    IssueCount,
    CASE
        WHEN IssueCount = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS TestStatus
FROM QualityTests;
GO


SELECT
    'FactSales → DimProduct' AS TestName,
    COUNT_BIG(*) AS OrphanRows,
    CASE WHEN COUNT_BIG(*) = 0 THEN 'PASS' ELSE 'FAIL' END
        AS TestStatus
FROM gold.FactSales AS F
LEFT JOIN gold.DimProduct AS D
    ON F.ProductKey = D.ProductKey
WHERE D.ProductKey IS NULL

UNION ALL

SELECT
    'FactSales → DimSeller',
    COUNT_BIG(*),
    CASE WHEN COUNT_BIG(*) = 0 THEN 'PASS' ELSE 'FAIL' END
FROM gold.FactSales AS F
LEFT JOIN gold.DimSeller AS D
    ON F.SellerKey = D.SellerKey
WHERE D.SellerKey IS NULL

UNION ALL

SELECT
    'FactOrders → DimCustomer',
    COUNT_BIG(*),
    CASE WHEN COUNT_BIG(*) = 0 THEN 'PASS' ELSE 'FAIL' END
FROM gold.FactOrders AS F
LEFT JOIN gold.DimCustomer AS D
    ON F.CustomerKey = D.CustomerKey
WHERE D.CustomerKey IS NULL

UNION ALL

SELECT
    'FactPayments → DimPaymentType',
    COUNT_BIG(*),
    CASE WHEN COUNT_BIG(*) = 0 THEN 'PASS' ELSE 'FAIL' END
FROM gold.FactPayments AS F
LEFT JOIN gold.DimPaymentType AS D
    ON F.PaymentTypeKey = D.PaymentTypeKey
WHERE D.PaymentTypeKey IS NULL

UNION ALL

SELECT
    'FactReviews → DimOrderStatus',
    COUNT_BIG(*),
    CASE WHEN COUNT_BIG(*) = 0 THEN 'PASS' ELSE 'FAIL' END
FROM gold.FactReviews AS F
LEFT JOIN gold.DimOrderStatus AS D
    ON F.OrderStatusKey = D.OrderStatusKey
WHERE D.OrderStatusKey IS NULL;
GO



SELECT
    COLUMN_NAME,
    DATA_TYPE,
    ORDINAL_POSITION
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'gold'
  AND TABLE_NAME IN ('FactSales', 'FactPayments')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
GO


SELECT
    'Invalid review scores' AS TestName,
    COUNT_BIG(*) AS IssueCount,
    CASE
        WHEN COUNT_BIG(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END AS TestStatus
FROM gold.FactReviews
WHERE ReviewScore NOT BETWEEN 1 AND 5

UNION ALL

SELECT
    'Negative item prices',
    COUNT_BIG(*),
    CASE
        WHEN COUNT_BIG(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END
FROM gold.FactSales
WHERE ItemPrice < 0

UNION ALL

SELECT
    'Negative freight values',
    COUNT_BIG(*),
    CASE
        WHEN COUNT_BIG(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END
FROM gold.FactSales
WHERE FreightValue < 0

UNION ALL

SELECT
    'Negative payment values',
    COUNT_BIG(*),
    CASE
        WHEN COUNT_BIG(*) = 0 THEN 'PASS'
        ELSE 'FAIL'
    END
FROM gold.FactPayments
WHERE PaymentValue < 0;
GO